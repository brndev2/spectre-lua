-- Lua provided by RyzenAPI
-- Game: Days Gone

-- MAIN APPLICATION
addappid(1259420)
addappid(3238470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1259421, 1, "3a92a76d80b16038abe5b2831f554a22120535ab039dbde663a70c8b52afe11b")

-- MANIFESTS / UPDATES
setManifestid(1259421, "9008749683399927967")
setManifestid(228990, "1829726630299308803")
setManifestid(228988, "6645201662696499616")
