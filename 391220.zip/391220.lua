-- Lua provided by RyzenAPI
-- Game: Rise of the Tomb Raider™

-- MAIN APP DEPOTS / PACKAGES
addappid(391220, 1, "471c9dc9264dee70d998fa09da81085cbd8635f7eac85e0aad3037c29c26510a") --Mainappid Rise of the Tomb Raider™
addappid(391221, 1, "4b20550dff2d439457b19fd7ce04667d20b9b234e8be4ef0284632a2b99cfdee") --Main Windows Depot Rise of the Tomb Raider™
addappid(391222, 1, "f4e85421721124a989c839016776ff38b30720aa7f8a2f31abc68109641ae515") --Main Windows Depot Rise of the Tomb Raider™
addappid(391223, 1, "548e5f09aa216df75d9c5e329210136ead85abe8669a6dd6a10448226e595028") --Main Windows Depot Rise of the Tomb Raider™
addappid(391224, 1, "ad3fbd6c645319a5728681f01632e85945306f0c8243bf624e34e1a9d652d38c") --Main Windows Depot Rise of the Tomb Raider™
addappid(391225, 1, "a6fce33f31f484aeb2c88a1291f51b72312c52d896f18e6961233d96b9ff0e99") --Main Windows Language Depot French Rise of the Tomb Raider™
addappid(391226, 1, "bb3ebded5e09339b7a508658189823d1ce6006586cabab468cf5b0b530b3ea1a") --Main Windows Language Depot Italian Rise of the Tomb Raider™
addappid(391227, 1, "b484c6cd699f5beb0442f75791501057cdd1f0653489e87df1f3a4950004b2d8") --Main Windows Language Depot Spanish Rise of the Tomb Raider™
addappid(391228, 1, "9288004613d2c8b604f3605ba3bb75cf5955f1c6cf9690852bc93a8b6be9309c") --Main Windows Language Depot Brazilian Rise of the Tomb Raider™
addappid(391229, 1, "f9a8112598b324236b84c4c202d0344c0073d4ca6331e33a4923d59019fd9d50") --Main Windows Language Depot Russian Rise of the Tomb Raider™
addappid(391230, 1, "077e6fc47932216765677778caa4fe0aaa3020f7d866426af20e2ce9032f08d6") --Main Windows Language Depot Japanese Rise of the Tomb Raider™
addappid(391231, 1, "0848f2ab802a10ecc63fa98d4e3303f31c34c045291d1dab4430a7556bca10c7") --Main Windows Language Depot Koreana Rise of the Tomb Raider™
addappid(391232, 1, "fb22852277547a64f7cac5aa0d058b4078dc1ac29c38e630fbfb815f27aa0dc2") --Main Windows Language Depot German Rise of the Tomb Raider™
addappid(391233, 1, "930d4adf23dd7ee05c1d9f169d6f162c77472295d265b5e16aaa469f1ecc1942") --Main Windows Language Depot Tchinese Rise of the Tomb Raider™
addappid(391234, 1, "9661bcee9bdf0ff25f0d2b24a078a8d348a4edd5f1404863bd1af3fa996f651a") --Main Windows Language Depot Schinese Rise of the Tomb Raider™
addappid(391235, 1, "432e46edaec0522daf64ae73158b9d2323459f9c20cd7636f12bf2f418b10deb") --Main Windows Language Depot Polish Rise of the Tomb Raider™
addappid(391236, 1, "e79951c00f7b7dd890bf7e80937f3fd66b86e48758e04f3aa34b1583998d0ef4") --Main Windows Language Depot Dutch Rise of the Tomb Raider™
addappid(391237, 1, "edcccc4fa0af04b22875e776489ad0eb5a1fd589faa5e5b444632d2a4881087d") --Main Windows Language Depot Spanish Rise of the Tomb Raider™
addappid(391239, 1, "8808e80de68e7a918f1695a4cef456cea509d4a22350f7c524a38e9e2c72160d") --Main Windows Depot Rise of the Tomb Raider™
addappid(406201, 1, "a0d1cf061376d1e3eb1255c7fc027146c8c5d7476bbc32f66b9c050759eea2fd") --Main Macos Depot Rise of the Tomb Raider™
addappid(406202, 1, "08d992706b86c8607ba23e2f025b2d4420e4376b2ddba8df16982418a712f180") --Main Macos Depot Rise of the Tomb Raider™
addappid(418691, 1, "dd9118c8f999c83857f43354acd0bda0f517bbf1bc3727f6bc22d6944371d20a") --Main Macos Depot Rise of the Tomb Raider™
addappid(418692, 1, "30fd2d444a9cec549365dfe508273fb59d9f626ea15bc016d9d62c6dd4046814") --Main Macos Language Depot French Rise of the Tomb Raider™
addappid(418693, 1, "dd7cb480b627a87a4a280984fa238126b64dd310e145922c054da9b98a3abe78") --Main Macos Language Depot Italian Rise of the Tomb Raider™
addappid(418694, 1, "ca091b3f878892f67a637df2b65de023e9943b3eb33a3fc467430baf0a35d8a6") --Main Macos Language Depot Spanish Rise of the Tomb Raider™
addappid(418695, 1, "2ff342de1b8cb6f914198416aae7a81277073d365488b2dbe02746589b829161") --Main Macos Language Depot Brazilian Rise of the Tomb Raider™
addappid(418696, 1, "55153502b126e93b241cbe0ab4db07f5cc6bd267ceabb2eef0a8c4f90481a053") --Main Macos Language Depot Russian Rise of the Tomb Raider™
addappid(418697, 1, "df35260bf0552febd959a10a27374d80836dce4f6a62030ed829b1e5834116c1") --Main Macos Language Depot Japanese Rise of the Tomb Raider™
addappid(418698, 1, "7ba576616544db98408a4c1ae0196e4930ad944c948320844f0a29e009f0997b") --Main Macos Language Depot Koreana Rise of the Tomb Raider™
addappid(418699, 1, "56c968fdb63f4125df54f2cde07383b58ffc8a5263ecd875f3e1bab40f458b47") --Main Macos Language Depot German Rise of the Tomb Raider™
addappid(418701, 1, "aa45c2047058a9db25538fda4ee9bff970df03971c1976fe44023dc640fb7825") --Main Macos Language Depot Tchinese Rise of the Tomb Raider™
addappid(418702, 1, "110fb217efd40272e947715fc1cc35258b0d9c93e60eac7e1d60e9167b8cf26e") --Main Macos Language Depot Schinese Rise of the Tomb Raider™
addappid(418703, 1, "6b2daf7ceac1b773de79973a25e9b7cddf9e6b15e2d3150b31802f8cb82ee3ac") --Main Macos Language Depot Polish Rise of the Tomb Raider™
addappid(418704, 1, "b426ea8a9ef37a6b9412a2d2ed58eef26fd3e8bada709bec89d9ea6a740b9d8e") --Main Macos Language Depot Dutch Rise of the Tomb Raider™
addappid(418705, 1, "07b4911df615f12362f76a854ff76b7ffe48a4abf5dbdda68cf2e39578b95574") --Main Macos Language Depot Spanish Rise of the Tomb Raider™
addappid(418707, 1, "8e0cb16176db44623e506fbcee81bbbe02d4276eda278f290a044845e18a95b9") --Main Macos Depot Rise of the Tomb Raider™
addappid(418711, 1, "259dcc42a20941078d42a146d1e54f093920cdc5219ddbde5c618b0f52ea43d6") --Main Linux Depot Rise of the Tomb Raider™
addappid(418712, 1, "3e81a7630dab83f4fe90892999d11b0b9b6f739e6576f0b3da1340e61a307dfb") --Main Linux Depot Rise of the Tomb Raider™
addappid(418731, 1, "aa364a0c4c8810e7687625846aa30f55681830b4747a221f4afa82e77e37639c") --Main Linux Depot Rise of the Tomb Raider™
addappid(418732, 1, "d9b47eea35183d2ba23d86e6523f3eb833a555e7a19d9bff7b992b9b89c19ea2") --Main Linux Language Depot French Rise of the Tomb Raider™
addappid(418733, 1, "32f80c8acc8ccfcf77c365e6f1db19b543c52491e6cb63bf16520814e3a5c0f1") --Main Linux Language Depot Italian Rise of the Tomb Raider™
addappid(418734, 1, "21df8c59d28fc767df88686838750c640cf4f09af12872d5953e94565ceec68a") --Main Linux Language Depot Spanish Rise of the Tomb Raider™
addappid(418735, 1, "f6c7979995cdd3b2263b61d06dd6e4ec784b5a9193640d2ddf6ed37d341395b7") --Main Linux Language Depot Brazilian Rise of the Tomb Raider™
addappid(418736, 1, "6beb3be0fc37cb290a92b6e3384073c9fdf099da996f42023a46271a03216f27") --Main Linux Language Depot Russian Rise of the Tomb Raider™
addappid(418737, 1, "ff2ff3a74eb776ef8afe5ac57c86a8f7d92cfbcc991c1a967051dcda395953e6") --Main Linux Language Depot Japanese Rise of the Tomb Raider™
addappid(418738, 1, "d4e76f0c1f80db95e5096a4d141870813a7a8a9fb693e0ba92a9e961fa410861") --Main Linux Language Depot Koreana Rise of the Tomb Raider™
addappid(418739, 1, "804655c1bbf3ca5a9861c5c104abc359adecd0e500a33bc90cb5abda80d6bb97") --Main Linux Language Depot German Rise of the Tomb Raider™
addappid(418741, 1, "b16060cce2a0539938190cb184ebc7e041846dbbe0ac386bb677b511430b7f8a") --Main Linux Language Depot Tchinese Rise of the Tomb Raider™
addappid(418742, 1, "815815fb22bbd2ab04d8e712b4d28a77711241664f55f1d974bc3bf88a943458") --Main Linux Language Depot Schinese Rise of the Tomb Raider™
addappid(418743, 1, "8c431f3e05adc445a799f99d14d5cc4d6e750925cc90d62551cba9e1da769d15") --Main Linux Language Depot Polish Rise of the Tomb Raider™
addappid(418744, 1, "afd230813dff1a2743914318d0e35b62cc132626a739a36f2011d2574c044141") --Main Linux Language Depot Dutch Rise of the Tomb Raider™
addappid(418745, 1, "50113df47ee173976f5b6afdd2cdaf20d2ca5365f9c0681eedb85210d382ed5f") --Main Linux Language Depot Spanish Rise of the Tomb Raider™
addappid(418747, 1, "00a7b1527bfd42eb26b9dbf586abeb178eb28417966f147ffff9a5d76f003f64") --Main Linux Depot Rise of the Tomb Raider™
addappid(418752, 1, "22d0cbf2522db51becc2f382050cb2bd0df36c51c3043e5b21971ad381a50a59") --Main Linux Depot Rise of the Tomb Raider™
addtoken(418680, "12301003022257728778")
addappid(418680, 1, "c334c6d817272df8958fa655d8095ba4fb1cfca2e0d640e9cc745068054a5786") --Dlcname Sparrowhawk Pack
addappid(406207, 1, "67060caf396b70bdb7ef2173b63b7db69b3ffe82e131ae2e39b3e77c881c57ba") --Dlc Macos Depot Sparrowhawk Pack
addappid(418717, 1, "a3b4c26bec81c06ff9f7fe150854b577cde304ad6f74c5e6f8f033c5cf8339cd") --Dlc Linux Depot Sparrowhawk Pack
addtoken(418690, "14257662420320135979")
addappid(418690, 1, "cee2a48588ab6a3a3149a6590b713a78a68ee52e6287f579623fd4191ee56944") --Dlcname Hope's Bastion Pack
addappid(406205, 1, "4928e7bc8c8cb1829af32c993a40e0e1e83ef9b40171c4c465ed840e72912cf6") --Dlc Macos Depot Hope's Bastion Pack
addappid(418715, 1, "380b5162513d58b9e500821357fd16baef22e0a09da054e7a5d6e7e408f122e6") --Dlc Linux Depot Hope's Bastion Pack
addtoken(418700, "18405081464328861625")
addappid(418700, 1, "0ddef51c1e14d68cdacddc47dd2874fb82d267220354224a5570616f5aaf9e6d") --Dlcname Tactical Survivor Pack
addappid(406204, 1, "915d3a08f592faab9d9337d28ca3dea185cc7c0ce3bb4d2f10049d489ef896ed") --Dlc Macos Depot Tactical Survivor Pack
addappid(418714, 1, "41beeafbece0ae3c02fdd751da9be951ad1a4b78bd9f9366ae8b3f33d39b7a90") --Dlc Linux Depot Tactical Survivor Pack
addtoken(418710, "17593108361864258591")
addappid(418710, 1, "a6fa76e87a255ea8377abb69a068ac207ad3e9c4799620795df58e8fc34eed7c") --Dlcname Apex Predator Pack
addappid(406206, 1, "6bbe32863c03f88b9ba74fb1c8dbb0d95d8e72dd936c13ef1f512b11302eb5bd") --Dlc Macos Depot Apex Predator Pack
addappid(418716, 1, "4ba71f22c4c14e549bf8156fac1e74ebb0aba53743969ce7a7b72e6cd52c89b4") --Dlc Linux Depot Apex Predator Pack
addappid(418730) --Dlcname AppID 418730
addappid(418718, 1, "1b271aebb2d440063ea3f6670ffe1a1b4bdac8d3d0edadb4b6d6f2b54dad3990") --Dlc Linux Depot AppID 418730
addappid(418740) --Dlcname AppID 418740
addappid(418681, 1, "e960dc7686411545b722858ee2cc4f19ee94f52afaeddd5db89436a016249f03") --Dlc Macos Depot AppID 418740
addappid(418750, 1, "38b7e58955acd182e5cb9876b6c3b062227feb7005f5b19445c079eb996d67fc") --Dlcname Wilderness Survivor
addappid(406209, 1, "418d1a3cd9097968c6950e02af9250f2c2142479d2c1865504f52b1bb62d2f53") --Dlc Macos Depot Wilderness Survivor
addappid(418719, 1, "0447ca019b5295eb38ae4c9bf94a3532b3f71e96b88d274c1c1f5cabc43de9be") --Dlc Linux Depot Wilderness Survivor
addappid(418760, 1, "dda476c21b84d2eb6d98b34870ace2798f7ef92f6320a69ac29aeea4a3346c10") --Dlcname Siberian Ranger
addappid(418685, 1, "99bbb595d0c990894be2f2ca44ed81638c5d9ca7330b184d9587067c4caf8ee2") --Dlc Macos Depot Siberian Ranger
addappid(418725, 1, "77990b748498ee69a62afaed827c69329643af283d4a849161d998466d8c4685") --Dlc Linux Depot Siberian Ranger
addappid(418770, 1, "4bec24bf67a9f50aeee6d1f2274b524dd02b54ea06cfa22e78b7d1bae7522585") --Dlcname Ancient Vanguard
addappid(418684, 1, "93e03d950ef1f5c21febd58578c1b0168913fab19d24e4fe3c91d17f9edd8d92") --Dlc Macos Depot Ancient Vanguard
addappid(418724, 1, "e7fa30198e5249aa3ee684eb818c07b51a8d97e629a81de18b9aacc49ea15d4b") --Dlc Linux Depot Ancient Vanguard
addappid(418780, 1, "7a99ef0386046a7684afb7f47db824a0e22e39d978dc4b8acf00c2cf5976d0d5") --Dlcname Prophet's Legacy
addappid(418683, 1, "e8367b40c7b921edeb0150c39af5d1455ec0fdad64ce7b1c9d27425d94605f3f") --Dlc Macos Depot Prophet's Legacy
addappid(418723, 1, "c940a65ca87057b0c95915bce2f1ac4ac456a66ea209da921e0d7b2c77139e1d") --Dlc Linux Depot Prophet's Legacy
addappid(418790, 1, "3d690a0e79f9e89b31e14f8a35e8da3a6adf9e852d158b65e8c745b344bff448") --Dlcname Endurance
addappid(418682, 1, "c761d75897563507ec608d02a65990977ec0bad94b74e5a91ec110dca3f42911") --Dlc Macos Depot Endurance
addappid(418722, 1, "776eaa6d50e5535a4c69acc1278a4ab264ace000481de831813f4e90cc0721db") --Dlc Linux Depot Endurance
addappid(418800, 1, "bc37ded59d21226903be042ab971b44ea22b653ce69b8140684a200405ae0bb5") --Dlcname Baba Yaga
addappid(418686, 1, "7b438f31580157b8c12a51de3ac0a2b193af802ba37d098550fe34209cf8a21a") --Dlc Macos Depot Baba Yaga
addappid(418726, 1, "7fcf9c2295b3c8c6baafd257c73c7dfd3718c760b1cbb79716520f3cf1a216ac") --Dlc Linux Depot Baba Yaga
addappid(418810, 1, "5b9790e432814942095453c12202e256572ecb17b110879a0c2ad4ffadba99f1") --Dlcname Cold Darkness
addappid(418687, 1, "ebb481506e66290a4dccbed95338e42bef1b7986d5d01cae7d6642a415102232") --Dlc Macos Depot Cold Darkness
addappid(418727, 1, "0148b1205f64050634858cabed7c97d39fd666c6396aee6a592d97b7362b4f15") --Dlc Linux Depot Cold Darkness
addappid(419100) --Dlcname AppID 419100
addappid(418689, 1, "9e478cbdcff5b5c94dd6f44611f5eccf34c237daa1006f3c64a102b46c57e3ec") --Dlc Macos Depot AppID 419100
addappid(418729, 1, "ef6227f7105d72b71c4a514c260631c0dc493b35fb9fc605b7f248db77c51677") --Dlc Linux Depot AppID 419100
addappid(419110, 1, "b2dca5e25e63b9c58d5736b7000b897efa81c670af1b18c4a3a330f7d0a98a0d") --Dlcname Remnant Resistance Pack
addappid(418688, 1, "f6b8ee36856cdecef160e929ff3d0dc2cf5c2ab2ef910e7ee4d9074bc03b3530") --Dlc Macos Depot Remnant Resistance Pack
addappid(418728, 1, "6057c7cc0533e1b098315684d57139fa2c4d12e7c34b1a6b3e8137fab40abb64") --Dlc Linux Depot Remnant Resistance Pack
addappid(437800) --Dlcname Season Pass Card Packs
addappid(391238, 1, "bc60059dcf545829a337a732d4c545041d08fbbb95982844853596233c3bd0a8") --Dlc Windows Depot Season Pass Card Packs
addappid(418706, 1, "92f8d506ed9aa845376dfdc30b59474cf4c2bf9d869d6ca8d9c14715c1031774") --Dlc Macos Depot Season Pass Card Packs
addappid(418746, 1, "2c9fb8a0ce207077400de55a13e5352e5ade0a52f2b839841b84853d85355682") --Dlc Linux Depot Season Pass Card Packs
addappid(505540, 1, "a579b9897694af78f69f4910404eed7d1714f838926af41ad3be9ed5a3344782") --Dlcname Rise of the Tomb Raider 20 Year Celebration Pack
addappid(418708, 1, "0f32e17ec5b8b87838e7c2d875147b1cc57d26422e0db872ef3c126b1a1a6d33") --Dlc Macos Depot Rise of the Tomb Raider 20 Year Celebration Pack
addappid(418748, 1, "25340f6531fbaaa8db0b0b7adc9f859832098bae3d64ef8f7d22f88d7618248c") --Dlc Linux Depot Rise of the Tomb Raider 20 Year Celebration Pack
addappid(541750, 1, "3dd761de5147215c14e567f25111321eb66d5ce04efe45a5694e978fc724c27c") --Dlcname Valiant Explorer
addappid(418709, 1, "0f9e954abf8bbc9e5be696c94f765d1c0ae348883bb420e47090f40853416dc1") --Dlc Macos Depot Valiant Explorer
addappid(418749, 1, "1712973f4e37264b7bb3104eb4af2f02f2da4d7725b461e3bf12755c4d6a69b7") --Dlc Linux Depot Valiant Explorer
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
addappid(418720) --Dlcname Remnant Resistance Pack (Retired)
addappid(526660) --Dlcname Rise of the Tomb Raider - Season Pass
addtoken(526660, "14657769662039300484")

-- MANIFESTS / UPDATES
setManifestid(391221, "4794078318850798771", 20997449888)
setManifestid(391222, "5844778674994925496", 34823696)
setManifestid(391223, "1584369543637364543", 116875312)
setManifestid(391224, "717555914580032111", 652173280)
setManifestid(391225, "2037862665887144967", 634011536)
setManifestid(391226, "3228472152809892595", 636047088)
setManifestid(391227, "2311075211562466793", 636278800)
setManifestid(391228, "3447789117748845745", 637537632)
setManifestid(391229, "7526916024548181027", 626422032)
setManifestid(391230, "8160262224150489223", 640351568)
setManifestid(391231, "7389939237148851516", 612869680)
setManifestid(391232, "6995233117885027935", 629360784)
setManifestid(391233, "3407217971734066887", 614822064)
setManifestid(391234, "6791409369597795897", 610278176)
setManifestid(391235, "928597437214822380", 644914640)
setManifestid(391236, "56077480204299671", 0)
setManifestid(391237, "3363089993390661518", 640450576)
setManifestid(391239, "6943434998710716879", 172888592)
setManifestid(406201, "2449526556645486645", 18896497168)
setManifestid(406202, "2105459422924640653", 110903808)
setManifestid(418691, "263178854118548478", 652173280)
setManifestid(418692, "17026752736112632", 634011536)
setManifestid(418693, "205345161368202436", 636047088)
setManifestid(418694, "169309165006712900", 636278800)
setManifestid(418695, "159807319806050175", 637537632)
setManifestid(418696, "287462484679590851", 626422032)
setManifestid(418697, "24259875548083893", 640351568)
setManifestid(418698, "358921103046038785", 612869680)
setManifestid(418699, "23918736631012744", 629360784)
setManifestid(418701, "484963426894976687", 614822064)
setManifestid(418702, "55177290492148553", 610278176)
setManifestid(418703, "146868625520025557", 644914640)
setManifestid(418705, "659327018627932221", 640450576)
setManifestid(418707, "6272051870745712588", 166492624)
setManifestid(418711, "5640750343099000175", 18894962688)
setManifestid(418712, "7392977764999912661", 161001904)
setManifestid(418731, "19708515709860292", 652173280)
setManifestid(418732, "220152240934282361", 634011536)
setManifestid(418733, "194460484124545610", 636047088)
setManifestid(418734, "15774690292967377", 636278800)
setManifestid(418735, "444076963789533616", 637537632)
setManifestid(418736, "667678225186524344", 626422032)
setManifestid(418737, "231418129521000173", 640351568)
setManifestid(418738, "213576900245979111", 612869680)
setManifestid(418739, "498821977448874064", 629360784)
setManifestid(418741, "284893599092064941", 614822064)
setManifestid(418742, "182010283594917688", 610278176)
setManifestid(418743, "333814133725336179", 644914640)
setManifestid(418744, "5674783858863345085", 0)
setManifestid(418745, "356187523817903614", 640450576)
setManifestid(418747, "312637269899635799", 166492624)
setManifestid(406207, "207342535593864879", 240)
setManifestid(418680, "378942671148969575", 240)
setManifestid(418717, "196087258367907", 240)
setManifestid(406205, "92092700736411187", 240)
setManifestid(418690, "65115631254540684", 240)
setManifestid(418715, "54789389209863147", 240)
setManifestid(406204, "235011932828729614", 256)
setManifestid(418700, "898782230419067554", 256)
setManifestid(418714, "65951016426039747", 256)
setManifestid(406206, "86883524746510348", 256)
setManifestid(418710, "51443339483951151", 256)
setManifestid(418716, "255044434464154730", 256)
setManifestid(418718, "12374941091954185", 256)
setManifestid(418681, "256325867979355363", 256)
setManifestid(406209, "165830735221096045", 272)
setManifestid(418719, "190060527985473319", 272)
setManifestid(418750, "4490860606175189512", 272)
setManifestid(418685, "688684846377209851", 256)
setManifestid(418725, "87354691823539208", 256)
setManifestid(418760, "9102585270140874084", 256)
setManifestid(418684, "234748042072976737", 256)
setManifestid(418724, "1332933314892876", 256)
setManifestid(418770, "8227735745325821939", 256)
setManifestid(418683, "755832660793684514", 256)
setManifestid(418723, "292573332135546896", 256)
setManifestid(418780, "7818447123364089517", 256)
setManifestid(418682, "1028611266795863913", 400378576)
setManifestid(418722, "170564897590864783", 400378576)
setManifestid(418790, "4863695610568968480", 400921536)
setManifestid(418686, "72631022377414561", 988589872)
setManifestid(418726, "10904134873385159", 988589872)
setManifestid(418800, "1128899172093090204", 988577072)
setManifestid(418687, "873409895737513332", 456703504)
setManifestid(418727, "243497959333404937", 456703504)
setManifestid(418810, "9124905136754144422", 458156976)
setManifestid(418689, "16034772061691267", 240)
setManifestid(418729, "679335130406358239", 240)
setManifestid(418688, "57474434102667673", 272)
setManifestid(418728, "625379033836074028", 272)
setManifestid(419110, "4202803323130042", 272)
setManifestid(391238, "5737154611580587931", 192)
setManifestid(418706, "298905414625688581", 192)
setManifestid(418746, "188953858239603301", 192)
setManifestid(418708, "451826079657370082", 1668509376)
setManifestid(418748, "140386892066141374", 1668509376)
setManifestid(505540, "280490579396787619", 1671937664)
setManifestid(418709, "519081546379224304", 240)
setManifestid(418749, "73052998062838263", 240)
setManifestid(541750, "2547732432675892584", 240)
setManifestid(228984, "2547553897526095397", 13436144)
setManifestid(228990, "1829726630299308803", 100658080)
