-- Lua provided by RyzenAPI
-- Game: Crash Bandicoot™ 4: It’s About Time

-- MAIN APP DEPOTS / PACKAGES
addappid(1378990, 1, "e79d2cdbf79fcc0bb135e34c741d59bbf1f3eb3e4d3ff57683450da26a4e1826") --Mainappid Crash Bandicoot™ 4: It’s About Time
addappid(1378991, 1, "f50ac282f4e8cd6aa1b2477faf75a2d4ac2257737e16ccc8c08533eed66df9c9") --Main Windows Depot Crash Bandicoot™ 4: It’s About Time
addappid(1378992, 1, "0472c66839b11731f139af60a48c4d4295051038aa705924072f4f5931162592") --Main Windows Depot Crash Bandicoot™ 4: It’s About Time
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables

-- MANIFESTS / UPDATES
setManifestid(1378991, "6531755016801697470", 53716816)
setManifestid(1378992, "7776315403696891647", 24621452560)
setManifestid(228990, "1829726630299308803", 100658080)
