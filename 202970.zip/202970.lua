
-- Game: Call of Duty®: Black Ops II

-- MAIN APP DEPOTS / PACKAGES
addappid(202970, 1, "6e54aac3bcb773dca1584ae5a90c98f6087d01676fb2056e79db89b199c440b0") --Mainappid Call of Duty®: Black Ops II
addappid(202971, 1, "c2ccd46ae96d92b8097d23e8c3675bc72730ce50f38e23bc08e70ca05143bcec") --Main Windows Depot Call of Duty®: Black Ops II
addappid(202972, 1, "e8efd4d7d2c05ac03f3bd26bb3e9c8b0e83d58e3541f0e8f8da9f0a39f8fc16f") --Main Windows Depot Call of Duty®: Black Ops II
addappid(202973, 1, "f0de510f4bfceb5f47e865e94467b3f127d33c4d0d5c81914a3a29c4fc2c8590") --Main Windows Depot Call of Duty®: Black Ops II
addappid(202974, 1, "4383fc6b7ca3cbd82be0683abd1ab79ad62f27bd7ac98eb54cb1bb453a649723") --Main Windows Depot Call of Duty®: Black Ops II
addappid(202975, 1, "74ab26ff68cd38526c1f50213fe8f82a58ada56a0cb042c29823442525f0148a") --Main Windows Language Depot English Call of Duty®: Black Ops II
addappid(202976, 1, "725f44b140834a21ac2bbba5a199e498272a0bbe869a124ae99ef5b15c35cc12") --Main Windows Language Depot French Call of Duty®: Black Ops II
addappid(202977, 1, "3f8d2a2911e6b8edec42a23a388b45636588e7541d8abd02da2a62209b322be3") --Main Windows Language Depot Italian Call of Duty®: Black Ops II
addappid(202978, 1, "6c720b0ffae43e2e7584280239773ae1d31877c8b7ced5ba44b85d1cbe06c467") --Main Windows Language Depot German Call of Duty®: Black Ops II
addappid(202979, 1, "a111e2527dbecf81028bb41873e9b1ec64eea27a919a4e623ccd10340b6f6754") --Main Windows Language Depot Spanish Call of Duty®: Black Ops II
addappid(202981, 1, "de66601e0d08a62b2d4580d4c53903e31df623c09f33a98d892a7ce017c74d8e") --Main Windows Language Depot English Call of Duty®: Black Ops II
addappid(202982, 1, "39bf9b7998c9364ba3b25edfbfbf9181e956e06a7f34c8bc07460643180cb9aa") --Main Windows Language Depot French Call of Duty®: Black Ops II
addappid(202983, 1, "c1b6f1d822b845ed999e09eba4c39aae45af9fe70477c3b59360b65bb424c3f2") --Main Windows Language Depot Italian Call of Duty®: Black Ops II
addappid(202984, 1, "7244c174cd23322c554053756e641892c3a23105f6114f0213909ec9243c7b84") --Main Windows Language Depot German Call of Duty®: Black Ops II
addappid(202985, 1, "18e6b3f838f175f52ce046927baf70a2473195515bc416e0da8fbbecd34b3bea") --Main Windows Language Depot Spanish Call of Duty®: Black Ops II
addappid(202987, 1, "0f658995c5af8c440a1f7b4f7a2ba3bfc8633c0dbce5d933dd59598353e7588f") --Main Windows Language Depot Polish Call of Duty®: Black Ops II
addappid(202996, 1, "a3efe5d0e7b9623c8732437c076280d2a6a8086bfaaf7e21833384a470ab7ff3") --Main Windows Language Depot Polish Call of Duty®: Black Ops II
addappid(202997, 1, "3688ca0dc337af67df29a0c8ee0b3702ca5db2d1ae69cc757344b10c7a76d135") --Main Windows Language Depot Russian Call of Duty®: Black Ops II
addappid(202998, 1, "4eae51754f9a91706005d9348c27f01e412062f6ff4db3a4dc7bf94529da60b6") --Main Windows Depot Call of Duty®: Black Ops II
addappid(212931, 1, "1bfa23fb44b6ae907d35c699df2ca329047a3fc8d799ac7adbe5f59b84a4a3fa") --Main Windows Language Depot English Call of Duty®: Black Ops II
addappid(212932, 1, "5582637895b55b41d978166c53e3056bcb2a47a423894b1677e66310986e645c") --Main Windows Language Depot French Call of Duty®: Black Ops II
addappid(212933, 1, "935387d11f582509a9c062fa90c44eea6e7e397ffaac3b7fd7768081426bae86") --Main Windows Language Depot Italian Call of Duty®: Black Ops II
addappid(212934, 1, "adfb1aaa13b4e1d0c5ec03003f643b4e73a0363d8599b415a3adce2ffd266fc5") --Main Windows Language Depot German Call of Duty®: Black Ops II
addappid(212935, 1, "9b4083ed36754d69bb425f84f7494eb880df3442907929dd4de84f9b84ca7462") --Main Windows Language Depot Spanish Call of Duty®: Black Ops II
addappid(212937, 1, "3cc03cb9f21b613b3be3d31083e4ff039a14699ed12aa19e7f357e43e12ba41c") --Main Windows Language Depot Polish Call of Duty®: Black Ops II
addappid(212938, 1, "fdda853da7f6551fe5981e5b5c468968cabe6d7236c78f2c5947017f4b86e9ff") --Main Windows Language Depot Russian Call of Duty®: Black Ops II
addappid(202988, 1, "4a988af5f6be73d6a7737fb375cf41c5a3a4071324c3f2fc94f93d48af5cbf2a") --Dlcname Call of Duty: Black Ops II Digital Deluxe
addappid(219092, 1, "6eb4af9cc7ed432ff402317620d36eaf3db695eed4672a51c58e4ef506236652") --Dlcname Call of Duty: Black Ops II - Zombies - Nuketown Zombies
addappid(219094, 1, "2e5a53ff93c388da9e33c69ad6c761c937508465d431046c220ab3b564409ef3") --Dlcname Call of Duty: Black Ops II - Soundtrack
addappid(219097, 1, "666df66958bcdb6a8362441d94cdb74319e93115e52c76f4e54b76b96b20b28c") --Dlcname Call of Duty®: Black Ops II Revolution
addappid(219098, 1, "619907c2abcae91b02f6d777150635a00adcd1df47d3e072546502e8006229fa") --Dlcname Call of Duty®: Black Ops II - Uprising
addappid(219101, 1, "fd41c1b9ddbbd9cc1a2109df66b0a585e09d923b2260845013295e0c77cd37b3") --Dlcname Call of Duty®: Black Ops II - Vengeance
addappid(219103, 1, "643975876cfc288fdee25bf481b45416f7a132ae9a9cacc736063da3137e1354") --Dlcname Call of Duty: Black Ops II - Apocalypse
addappid(219093) --Dlcname Call of Duty: Black Ops II - Digital Deluxe Content
addappid(219095) --Dlcname Call of Duty: Black Ops II - Season Pass Content

-- MANIFESTS / UPDATES
setManifestid(202971, "4170196157863797715", 6978064)
setManifestid(202972, "44054127954755624", 0)
setManifestid(202973, "131606837976547528", 0)
setManifestid(202974, "8534031140633404768", 0)
setManifestid(202975, "855173471322016522", 0)
setManifestid(202976, "398756463655539206", 0)
setManifestid(202977, "245449812372322261", 0)
setManifestid(202978, "2034345168780887552", 0)
setManifestid(202979, "1450519586995334306", 0)
setManifestid(202981, "1518616799282145751", 0)
setManifestid(202982, "7570547606740258750", 0)
setManifestid(202983, "1739014760789280632", 0)
setManifestid(202984, "6300658496372945401", 0)
setManifestid(202985, "7923968249460604779", 0)
setManifestid(202987, "2333343847506595594", 0)
setManifestid(202996, "471429897779379026", 0)
setManifestid(202997, "724981713647824764", 0)
setManifestid(202998, "216411158385088962", 0)
setManifestid(212931, "1794283193511346342", 0)
setManifestid(212932, "1706613889294561605", 0)
setManifestid(212933, "206815688973952347", 0)
setManifestid(212934, "972078337778086957", 0)
setManifestid(212935, "866013529280688255", 0)
setManifestid(212937, "1758123124268245239", 0)
setManifestid(212938, "596260357850385968", 0)
setManifestid(202988, "5488258952144004872", 0)
setManifestid(219094, "3038711571425126440", 0)
