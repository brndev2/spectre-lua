-- Game: Mimic Party

-- MAIN APP DEPOTS / PACKAGES
addappid(5053820, 1, "3687a910eb76c9e3eccddcb2ce6cc97c4bc5667ef8e20e668cbedc150283773a") --Mainappid Mimic Party
addappid(5053821, 1, "3bf0ccc9e3c7c0ff61adcadc28e45680676fe6f9a82c9c4ad55c417c532c35e6") --Main Windows Depot Mimic Party
addappid(5168110) --Dlcname All Characters

-- MANIFESTS / UPDATES
setManifestid(5053821, "6004098785465827564", 145994976)
