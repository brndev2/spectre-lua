-- Lua provided by RyzenAPI
-- Game: Grand Theft Auto: San Andreas – The Definitive Edition

-- MAIN APPLICATION
addappid(1547000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1547001, 1, "625ab457b256e557dc28337fec8a01b39731624ee6008b92670ac977c2691806")
addappid(1899671, 0, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")

-- MANIFESTS / UPDATES
setManifestid(1899671, "3914969219305676290")
setManifestid(228988, "6645201662696499616")
setManifestid(228990, "1829726630299308803")
setManifestid(1547001, "6814041191190748315")
