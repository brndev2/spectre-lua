-- Lua provided by RyzenAPI
-- Game: Crash Bandicoot™ N. Sane Trilogy

-- MAIN APPLICATION
addappid(731490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(731491, 1, "66bc6c9ffa8740c78dfc58ecf2a422883a6a3a30031fe52641f0060903610ab8")
addappid(731492, 1, "ca39fb3667416ca9ec3ac95ecb8fdfe1a11fc5bb2e9c2a429be87eb476df46d1")

-- MANIFESTS / UPDATES
setManifestid(228986, "8782296191957114623")
