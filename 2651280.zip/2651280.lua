-- Lua provided by RyzenAPI
-- Game: Marvel&#39;s Spider-Man 2

-- MAIN APP DEPOTS / PACKAGES
addappid(2651280, 1, "d191b462673cdb64c982bd00df30c97f296f643cc8a9bb6e5872554700055f4b") --Mainappid Marvel&#39;s Spider-Man 2
addappid(2651281, 1, "9874571b52ba0c01cbdfd32c5d81920d1093f42fbcf76d02a1e4589746a3b497") --Main Windows Depot Marvel&#39;s Spider-Man 2
addappid(2651282, 1, "ab459f096f7d0fd0720dd711f19036f532f2678314af4155ed197882c260b539") --Main Windows Depot Marvel&#39;s Spider-Man 2
addappid(2651283, 1, "e342794b2586f10e0a3273560bda0fb524b448519ff20b6ec938d03e5b949104") --Main Windows Depot Marvel&#39;s Spider-Man 2
addappid(2651284, 1, "11af403d500753e060bd806ed360e9bf5031e0e846a9ba50a876f68fcb61c641") --Main Windows Language Depot Arabic Marvel&#39;s Spider-Man 2
addappid(2651285, 1, "14ad0c77584264070ad5cbedf200f8747660475645d0527c93425de942df6d1b") --Main Windows Language Depot French Marvel&#39;s Spider-Man 2
addappid(2651286, 1, "f33f54c66e41670774919e410838c06145826bfabe00def0753399b0ffe58b4a") --Main Windows Language Depot German Marvel&#39;s Spider-Man 2
addappid(2651287, 1, "4ab098c2d61d6bc168fb4067cfc2377f9865275310e1e86c960a12de83a39ee9") --Main Windows Language Depot Italian Marvel&#39;s Spider-Man 2
addappid(2651288, 1, "0a0e8a531cc2d2483435dcc5d3d0969712b646c0718c39991b0e64d2e0b9a1fd") --Main Windows Language Depot Japanese Marvel&#39;s Spider-Man 2
addappid(2651289, 1, "14052de118633012aec3fe99b7a692bee3da4c8604d126f7b057f416d327c488") --Main Windows Language Depot Polish Marvel&#39;s Spider-Man 2
addappid(2666311, 1, "3bf280f2400be0851c8f7f1872d8c48884df409d8d8e933615ac85b9a972836a") --Main Windows Depot Marvel&#39;s Spider-Man 2
addappid(2666312, 1, "ecb0cd78998a33161c79c8cc7130a578af813aa46c6d8c54fe7227167ebba919") --Main Windows Language Depot Brazilian Marvel&#39;s Spider-Man 2
addappid(2666313, 1, "4cbc4b49aefb9e6a43312b89474b674d8147e3294baa418b46b3b6c34a9d6850") --Main Windows Language Depot Portuguese Marvel&#39;s Spider-Man 2
addappid(2666314, 1, "58b3013867940ee2998334b9c0412ab2ccc4310a529c231bb74cec034dd2c645") --Main Windows Language Depot Russian Marvel&#39;s Spider-Man 2
addappid(2666315, 1, "319c6ed61f3fd2d4571eed5b5132ba16c780d70712db62109e2aa814a912e803") --Main Windows Language Depot Latam Marvel&#39;s Spider-Man 2
addappid(2666316, 1, "49480a4027a30684386dc0f2b32494b7424bbbe67234983c07644a0211ccb61c") --Main Windows Language Depot Spanish Marvel&#39;s Spider-Man 2
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Share Windows Depot Steamworks Common Redistributables
addappid(3172650) --Dlcname Marvel's Spider-Man 2 - PC Purchase Perks
addappid(3172660) --Dlcname Marvel's Spider-Man 2 - Digital Deluxe Upgrade

-- MANIFESTS / UPDATES
setManifestid(2651281, "2482069238759486759", 93390513248)
setManifestid(2651282, "916267482687495772", 575435040)
setManifestid(2651283, "3857548638628631938", 3277411856)
setManifestid(2651284, "1775189146886779816", 2748589968)
setManifestid(2651285, "5361007891637566145", 2780499520)
setManifestid(2651286, "2162917891637945543", 2877738192)
setManifestid(2651287, "3343651597016904472", 2800417760)
setManifestid(2651288, "3065913522367144815", 2834358880)
setManifestid(2651289, "8039378510820213674", 2854764240)
setManifestid(2666311, "7167820393896288073", 0)
setManifestid(2666312, "4514414037079472295", 2673190240)
setManifestid(2666313, "4705404633151731858", 2745287856)
setManifestid(2666314, "8669021131468307666", 2996850448)
setManifestid(2666315, "5733166079877697458", 2857574672)
setManifestid(2666316, "4084921386261911799", 2938969712)
setManifestid(228989, "5753583882400741046", 25108528)
