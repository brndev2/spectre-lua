-- Lua provided by RyzenAPI
-- Game: Mafia II: Definitive Edition

-- MAIN APP DEPOTS / PACKAGES
addappid(1030830, 1, "66e03a662a0c337dbdb51349f55fb773c592ad0db801ad39254af1cb6c603c18") --Mainappid Mafia II: Definitive Edition
addappid(1030831, 1, "32530b6455aff62129bdca96b7eade4476d7d5aa76a6233563dca1ccad754475") --Main Windows Depot Mafia II: Definitive Edition
addappid(1523211, 1, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b") --Share Windows Depot AppID 1523210

-- MANIFESTS / UPDATES
setManifestid(1030831, "7075325167535131973", 37477823344)
setManifestid(1523211, "5488617169383930545", 128)
