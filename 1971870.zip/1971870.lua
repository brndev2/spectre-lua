-- Lua provided by RyzenAPI
-- Game: Mortal Kombat 1

-- MAIN APP DEPOTS / PACKAGES
addappid(1971870, 1, "fb3cf14a9a19a7cf00461b1475f92835ae9ed6564bba02e599aa4318dcd86c45") --Mainappid Mortal Kombat 1
addappid(1971872, 1, "2fb68660ef98508853b7901a8c4758d2811c558bc23eb52105126af40209be9c") --Main Windows Depot Mortal Kombat 1
addappid(1971873, 1, "1721fcefd622e29779c2aaf9b3c0b7fbad0d149f94d00e611b8185720bd65afb") --Main Windows Depot Mortal Kombat 1
addappid(1971874, 1, "d7c65f47842d7fe05e6489fd6f86355ebfb7a3f1261c503cdbeebaba66849d82") --Main Windows Depot Mortal Kombat 1
addappid(1971875, 1, "020f4d21f49e187c5ee0dc181a3d10cdc166bc935868f83e5add726947973b51") --Main Windows Depot Mortal Kombat 1
addappid(2615190) --Dlcname MK1: 4k Cinematic Pack
addappid(2615191, 1, "881b5265b81aaa6e34ba005510561510c74dca7c4ddf56e688110dc4708702f7") --Dlc Windows Depot MK1: 4k Cinematic Pack
addappid(3168020) --Dlcname MK1: Khaos Reigns 4k Cinematic Pack
addappid(3168021, 1, "30cb9e85c44a2e1796c48b863ad72b03f0c8c8944fc32e93af78420d958df89e") --Dlc Windows Depot MK1: Khaos Reigns 4k Cinematic Pack
addappid(3233540) --Dlcname MK1: Khaos Reigns Expansion
addappid(3233541, 1, "202206a238ab830b8c5dc5506ae41300989cd12ceadff8bb3c6d554bf3feb56b") --Dlc Windows Depot MK1: Khaos Reigns Expansion
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
addappid(2576730) --Dlcname MK1: Jean-Claude Van Damme Skin
addappid(2576740) --Dlcname MK1: Sub-Zero Día de Muertos Skin
addappid(2576750) --Dlcname MK1: Kollector's Edition Liu Kang Skin
addappid(2576760) --Dlcname MK1: Tanya Funkeira Skin
addappid(2576770) --Dlcname MK1: Kameo Unlock Pack
addappid(2576780) --Dlcname Kombat Pack
addappid(2576790) --Dlcname MK1: One-Time Dragon Pack
addappid(2576800) --Dlcname MK1: Shang Tsung
addappid(2576810) --Dlcname MK1: Havik
addappid(2586300) --Dlcname Premium Edition 1250 Dragon Krystals
addappid(2636080) --Dlcname MK1: Omni-Man
addappid(2636090) --Dlcname MK1: Tremor Kameo
addappid(2695680) --Dlcname MK1: Quan Chi
addappid(2695690) --Dlcname MK1: Khameleon
addappid(2777460) --Dlcname MK1: Peacemaker
addappid(2777480) --Dlcname MK1: Janet Cage
addappid(2880670) --Dlcname MK1: Ermac
addappid(2880680) --Dlcname MK1: Mavado
addappid(2968440) --Dlcname MK1: Homelander
addappid(2968450) --Dlcname MK1: Ferra
addappid(3049390) --Dlcname MK1: Takeda Takahashi
addappid(3133990) --Dlcname MK1: Khaos Reigns Expansion
addappid(3134000) --Dlcname MK1: Khaos Reigns Bundle
addappid(3161240) --Dlcname MK1: Khaos Reigns Bundle
addappid(3168140) --Dlcname MK1: Cyrax
addappid(3168150) --Dlcname MK1: Sektor
addappid(3168160) --Dlcname MK1: Noob Saibot
addappid(3168170) --Dlcname MK1: Khaos Reigns Skins Pack
addappid(3179910) --Dlcname MK1: Kollection Tracking
addappid(3226640) --Dlcname MK1: One-time Dragon Pack Kitana
addappid(3226650) --Dlcname MK1: Tournament Liu Kang
addappid(3286290) --Dlcname MK1: Ghostface
addappid(3286300) --Dlcname MK1: T-1000
addappid(3286310) --Dlcname MK1: Conan
addappid(3490300) --Dlcname MK1: Madam Bo
addappid(3497710) --Dlcname MK1: MKT Skins
addappid(3747420) --Dlcname Definitive Edition 1250 Dragon Krystals
addappid(3747600) --Dlcname MK1: Definitive Edition Upgrade
addappid(3749220) --Dlcname MK1: DE Skin Pack

-- MANIFESTS / UPDATES
setManifestid(1971872, "8552604172369068290", 334944000)
setManifestid(1971873, "5676539294652549514", 160)
setManifestid(1971874, "512005367846038723", 98857272384)
setManifestid(1971875, "2741683106529194428", 25112807696)
setManifestid(2615191, "4363176120155839027", 47895313808)
setManifestid(3168021, "9095445288428088123", 14394113632)
setManifestid(3233541, "9120506324946519517", 7621655072)
setManifestid(228989, "5753583882400741046", 25108528)
setManifestid(228990, "1829726630299308803", 100658080)
