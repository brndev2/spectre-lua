addappid(300820) --Mainappid Disney•Pixar Toy Story 3: The Video Game
addappid(300821, 1, "0e20a5f31271db9325f50cba1901b205d946b59f34731a33468fff2fa78c705e") --Main Windows Depot Disney•Pixar Toy Story 3: The Video Game
setManifestid(300821, "4723845939758216585", 1824193728)
addappid(300822, 1, "097aa19657ccac3e43c68c6433797a4125bd80c0034f77f44a7f03a794cd6067") --Main Windows Language Depot Czech Disney•Pixar Toy Story 3: The Video Game
setManifestid(300822, "1093847233351468919", 1682925424)
addappid(300823, 1, "bd349db85e26a4762a2f3c6ee502a94fdc45135eba5c25826d8803dae1d921d1") --Main Windows Language Depot Polish Disney•Pixar Toy Story 3: The Video Game
setManifestid(300823, "2720752851768981594", 1665505744)
addappid(300824, 1, "195ce4d8421eeee4a3dbc9ebc2b563a54b70d1a6701855b02b0d51463d96561a") --Main Windows Language Depot Danish Disney•Pixar Toy Story 3: The Video Game
setManifestid(300824, "5147673597686385682", 1675720624)
addappid(300825, 1, "cc8c3cdaff351d795ee3d8b1ca681a2390acd4e2415014ef4d257db202af1e44") --Main Windows Language Depot Swedish Disney•Pixar Toy Story 3: The Video Game
setManifestid(300825, "2033202489655916977", 1709480176)
addappid(300826, 1, "baf1cbacea8ba8b2a48667ef4c57f69dfb3a3d923f4fc57cb5a95dee92aabc9b") --Main Windows Language Depot Finnish Disney•Pixar Toy Story 3: The Video Game
setManifestid(300826, "3061028769765071797", 1688716480)
addappid(300827, 1, "3dfbb9792d219515bb06ad71ebe2281c05afa5dd8568dae9b659af30b281cfd7") --Main Windows Language Depot Norwegian Disney•Pixar Toy Story 3: The Video Game
setManifestid(300827, "6370562217729398368", 1680197280)
addappid(300828, 1, "b320d12748a65791b79ffe502981d048c515016a3bdb555b2f0166dbf4a88c32") --Main Windows Language Depot English Disney•Pixar Toy Story 3: The Video Game
setManifestid(300828, "6523676981648793655", 1792214624)
addappid(300829, 1, "c6094abd8661ea6991c863b1f95f1ce51efa8a2dc97e313de5826168f8613fcf") --Main Windows Language Depot French Disney•Pixar Toy Story 3: The Video Game
setManifestid(300829, "7353650582148928137", 1756511936)
addappid(301020, 1, "bb64bf5a9af843d293f082177c6c5bf98dba84e50015280622b48e14a5321046") --Main Windows Language Depot Italian Disney•Pixar Toy Story 3: The Video Game
setManifestid(301020, "6604119855155404007", 1769073568)
addappid(301021, 1, "0c7e407313f9d27d406a76e76d2b2bbc055daf7456b19309b90c097ecaadf09a") --Main Windows Language Depot German Disney•Pixar Toy Story 3: The Video Game
setManifestid(301021, "2518676903189347183", 1773271376)
addappid(301022, 1, "6f87172d7e74e5bbbab3d5f5c0a5e57dd138c1ad3853e68b6e0043ad98a78f7e") --Main Windows Language Depot Spanish Disney•Pixar Toy Story 3: The Video Game
setManifestid(301022, "3552464321420722186", 1776058784)
addappid(301023, 1, "d47ca0e5ad080229e096747cdf427ff8ceb8ed17b7e611275bc744f1725651fb") --Main Windows Language Depot Dutch Disney•Pixar Toy Story 3: The Video Game
setManifestid(301023, "3923462072917622057", 1769178016)
addappid(301024, 1, "4f146e0aed245a2da3de1ec0fde2fc8e3dd649d718d78c1044cb1b8b29b0209f") --Main Windows Language Depot Brazilian Disney•Pixar Toy Story 3: The Video Game
setManifestid(301024, "5099373221538203277", 1764415488)
addappid(301025, 1, "e89df2fe5d2d40c705fa137820112ae2f29c7e07802a78ecef4d62ac42393ecc") --Main Windows Language Depot Russian Disney•Pixar Toy Story 3: The Video Game
setManifestid(301025, "3057048892489225807", 1672782064)
--Share Depots
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228982, "6413394087650432851", 9650016)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)