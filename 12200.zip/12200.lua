addappid(12200, 1, "82dedf7e315b9eb744f42e96e2967ad2aed16cc8a1a9309369417ec5639a3428") --Mainappid Bully: Scholarship Edition
addappid(12201, 1, "b02e549a49b9318ee8352042cb5cfe08a4d103eb6a7a3526c27e4e6ec86ed57b") --Main Windows Depot Bully: Scholarship Edition
setManifestid(12201, "8414883404224460046", 3663459936)