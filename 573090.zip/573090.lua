addappid(573090, 1, "1385435ae44e48ac0fbea684d525581b864dd6e984b1469e68e029f37e820052") --Mainappid Stormworks: Build and Rescue
addappid(573091, 1, "49f609573f8fc3923ec4eab2ba459bdea77b7a906e9054549c102e4659fcfff7") --Main Windows Depot Stormworks: Build and Rescue
setManifestid(573091, "3859919618388340650", 397102496)
addappid(573092, 1, "871725b4b4314590b50465afe4c8ebd3cea63a704afce1ae1f369edecb0be7f5") --Main Macos Depot Stormworks: Build and Rescue
setManifestid(573092, "5301856878269901622", 281241552)
--Share Depots
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228985, "3966345552745568756", 13244128)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228988, "6645201662696499616", 22411856)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") --Share Windows Depot Steamworks Common Redistributables
setManifestid(229020, "5799761707845834510", 591984)
addappid(1542360) --Dlcname Stormworks: Search and Destroy
addappid(2124750) --Dlcname Stormworks: Industry
addappid(2383250) --Dlcname Stormworks: Space