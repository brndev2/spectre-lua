-- Lua provided by RyzenAPI
-- Game: Red Dead Redemption

-- MAIN APP DEPOTS / PACKAGES
addappid(2668510, 1, "9ace770b063cfbeeb4e05df2614a7c5a77e52bf12f87b3f35e9c6a26aa3c12a3") --Mainappid Red Dead Redemption
addappid(2668511, 1, "839eae6ac7edb75331c27732d207b339d78db2f2bd634989b08bd602a4c5983b") --Main Windows Depot Red Dead Redemption
addappid(2668512, 1, "ba1f0d8d7f0e02e8659bdd8d6a7738133974941d2da9845ae59a4f0fa456d801") --Main Windows Depot Red Dead Redemption
addappid(2668513, 1, "af2b732e108f2a10ed375b7042e3aa1cbdf57dc59dc07c303a7d9d31e81b9c59") --Main Windows Depot Red Dead Redemption
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
addappid(1899671, 1, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b") --Share Windows Depot RGL/SC

-- MANIFESTS / UPDATES
setManifestid(2668511, "870294950404908569", 400)
setManifestid(2668512, "4863697874015475084", 8710999520)
setManifestid(2668513, "14321031912871209", 8712324288)
setManifestid(228989, "5753583882400741046", 25108528)
setManifestid(228990, "1829726630299308803", 100658080)
setManifestid(1899671, "3914969219305676290", 209058416)
