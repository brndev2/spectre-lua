-- Lua provided by RyzenAPI
-- Game: Sonic Colors: Ultimate

-- MAIN APP DEPOTS / PACKAGES
addappid(2055290, 1, "42260acf2afe92d0d555cb0927fb0d5c37b2f86bb085fd1090519487dc33a529") --Mainappid Sonic Colors: Ultimate
addappid(2055291, 1, "35b064414a398875b2ba3c0482f2a5916ea85dd34c317a67157a42a8a6090b51") --Main Windows Depot Sonic Colors: Ultimate
addappid(2129040) --Dlcname Sonic Colors: Ultimate – Ultimate Cosmetic Pack
addappid(2154410) --Dlcname Sonic Colors: Ultimate – Music Pack
addappid(2189460) --Dlcname Sonic Colors: Ultimate – Movie Content 1
addappid(2189461) --Dlcname Sonic Colors: Ultimate – Movie Content 2
addappid(2189462) --Dlcname Sonic Colors: Ultimate – Movie Content 3
addappid(2189463) --Dlcname Sonic Colors: Ultimate – Movie Content 4

-- MANIFESTS / UPDATES
setManifestid(2055291, "7074340774677646098", 16480874608)
