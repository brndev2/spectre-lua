-- Lua provided by RyzenAPI
-- Game: Lossless Scaling

-- MAIN APP DEPOTS / PACKAGES
addappid(993090, 1, "16f541b7cbaad8feee0918c9282ec972b82991175b27c96de8843aec4f655451") --Mainappid Lossless Scaling
addtoken(993090, "6308073361085917231")
addappid(993091, 1, "3a02317ffe8c475c236c603a9fcd31c7cd8e4a109240f4c3d9fa28081bdc02bd") --Main Windows Depot Lossless Scaling
addappid(993092, 1, "7f42c4f024fecc789a821093226e8655818e4f981c698ff5f5bba81abe4edda3") --Main Windows Depot Lossless Scaling
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Share Windows Depot Steamworks Common Redistributables
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") --Share Windows Depot Steamworks Common Redistributables

-- MANIFESTS / UPDATES
setManifestid(993091, "2549887697121492489", 57169184)
setManifestid(993092, "3384896674095978390", 69833120)
setManifestid(228989, "5753583882400741046", 25108528)
setManifestid(229007, "4477590687906973371", 118846656)
