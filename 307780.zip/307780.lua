-- Lua provided by RyzenAPI
-- Game: Mortal Kombat X

-- MAIN APP DEPOTS / PACKAGES
addappid(307780, 1, "43952d7a2565b4900e2acd3c5fee7da8e3c1e0cdc655fd5427d56c03ba8dbda5") --Mainappid Mortal Kombat X
addappid(307781, 1, "1f7f19a9bf864918c90642857c72f26158edb7fad42c654c3e7b8223b22082fd") --Main Windows Depot Mortal Kombat X
addappid(307782, 1, "b7d533efdd22f4207278d2b7af52a5c93640666b36c168b959de01431f2ccda5") --Main Windows Depot Mortal Kombat X
addappid(307783, 1, "efe55fd4dc5501e4c50424d0c60e5c358c60f555ad66ce9a22378fed90804fb9") --Main Windows Depot Mortal Kombat X
addappid(307784, 1, "8d29fc1cac2b2a2e6d39047616eb83fa4c83ff6cb1d74bd1453ecf9c192e61ed") --Main Windows Depot Mortal Kombat X
addtoken(347150, "5056622398946101340")
addappid(347150, 1, "567f828cb5fb9f8101da5853b9a1275d3838c209dac533643a82b4d8c238cada") --Dlcname Character - Jason Voorhees
addtoken(347152, "18058496923834980440")
addappid(347152, 1, "50dc18e35d2e4757c4e64865d5d6a6cc03e1b981530f98ab137928b51f611ee1") --Dlcname Coarse (Gold) Scorpion
addtoken(347153, "6584886949805697405")
addappid(347153, 1, "d6827248f56319531816742fc89c2844a46a074d4e9cb751755538dd19ff04ac") --Dlcname Kollective Kold War Scorpion
addtoken(347154, "3732130513757837914")
addappid(347154, 1, "d42212674617019709b240ed2ae0603bd7fe3ec9910503cc566b0a1d064eabc2") --Dlcname Unlock All Krypt Content
addtoken(347155, "15778906085675687591")
addappid(347155, 1, "f080434be373fcc4c5e96ab2c6ed4948806fa0f599655cd78e90280119f71384") --Dlcname Blue Steel Sub-Zero
addtoken(347890, "16789513768132101430")
addappid(347890, 1, "42b1469fc20df168c0800d4fbc82ca39f7b7518f06e2a3d858632f83c15bfc08") --Dlcname Character - Goro
addtoken(351550, "2498884398632749421")
addappid(351550, 1, "54a9ebd379096a411ae1e67d93a1bf2f50cc3b4bacccd17928a23b599441394a") --Dlcname Character - Predator
addtoken(351551, "12129372819771042838")
addappid(351551, 1, "0947a73c31343a6ad0be7282b34c316e14ced5474c0c07c8d40878bd463753a3") --Dlcname Character - Tanya
addtoken(351552, "8700712936055303222")
addappid(351552, 1, "0c1192c5b43741770032760077c924160390a9a380b6a4b825c8ef3c48ed602a") --Dlcname Character - Tremor
addtoken(351553, "3434961170868107438")
addappid(351553, 1, "fdd70c2164677e35183d1082e3bc37a3d5f0b8913b6b7e36157309c8bb7c41a1") --Dlcname Skin Pack - Brazil
addtoken(351554, "145169343468324499")
addappid(351554, 1, "cdffabc419554361aa64c9afdb49c77f2712c37a123af9834f244e0df7402a6d") --Dlcname Skin Pack - Klassic Skins 1
addtoken(351555, "5086585344312368935")
addappid(351555, 1, "3458669120d39f55f18cdbadad33f57e49df28386576485cc2fe7b5016f144a1") --Dlcname Skin Pack - Kold War
addtoken(351556, "8777790268329434580")
addappid(351556, 1, "19dda8794a786b7f624caac1bf7808cdcf153195b68ab05c1cf6f17a0ec6f353") --Dlcname Skin Pack - Samurai
addappid(351557, 1, "2590ec63a0164c1ef39e4379ed1a933d034e9b876b2cb16f996f950ab0968f4c") --Dlcname AppID 351557
addtoken(351558, "11088132336965508389")
addappid(351558, 1, "b750b2890a4757f4e6c22150deb6e904c87dc00708fdd124bac4ba1004777f1b") --Dlcname Klassic Fatalities 1
addappid(351559, 1, "76833c2163d330634fefc37c5d510dc79610e5d6f19c99eed24c1e97f88b2431") --Dlcname AppID 351559
addappid(354413, 1, "e6e51d0adcf4e849a719110e9558d04d1afcf3bccbfa8ebe6235f1531c10d0ee") --Dlcname Klassic Fatalities 2
addtoken(354425, "3672485219721651993")
addappid(354425, 1, "53d201ab259e97138748462c1057e239aa382d9ed22e6bd208bf583ed7c240da") --Dlcname Skin Pack - Horror Skins
addtoken(354426, "373211202759467881")
addappid(354426, 1, "e034af50242c1fc1dd701d027734e31c5391559e6add5c48bffef0ca87237f35") --Dlcname Skin Pack - Klassic Skins 2
addtoken(354427, "7531775044434075858")
addappid(354427, 1, "ff20a63957fc349d3bf2ac512655b58f979e69b49d715d4a4805a25228c9b7d3") --Dlcname Skin Pack - Prey Skins
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
addappid(347880) --Dlcname Kombat Pack
addtoken(347880, "18019291952406674729")
addappid(524620) --Dlcname Kombat Pack 2
addtoken(524620, "11579146367400593429")
addappid(349160) --Dlcname AppID 349160
addappid(349170) --Dlcname AppID 349170
addappid(349171) --Dlcname AppID 349171
addappid(349172) --Dlcname AppID 349172
addappid(349173) --Dlcname AppID 349173
addappid(349174) --Dlcname AppID 349174
addappid(349175) --Dlcname AppID 349175
addappid(349176) --Dlcname AppID 349176
addappid(349177) --Dlcname AppID 349177
addappid(351560) --Dlcname AppID 351560
addappid(351561) --Dlcname AppID 351561
addappid(351562) --Dlcname AppID 351562
addappid(351563) --Dlcname AppID 351563
addappid(351564) --Dlcname AppID 351564
addappid(354410) --Dlcname AppID 354410
addappid(354411) --Dlcname AppID 354411
addappid(354412) --Dlcname AppID 354412
addappid(354414) --Dlcname AppID 354414
addappid(354415) --Dlcname AppID 354415
addappid(354416) --Dlcname AppID 354416
addappid(354417) --Dlcname AppID 354417
addappid(354418) --Dlcname AppID 354418
addappid(354419) --Dlcname AppID 354419
addappid(354420) --Dlcname AppID 354420
addappid(354421) --Dlcname AppID 354421
addappid(354428) --Dlcname AppID 354428
addappid(354429) --Dlcname AppID 354429

-- MANIFESTS / UPDATES
setManifestid(307781, "5624529206982116192", 3247548768)
setManifestid(307782, "6159674384328955878", 3120080)
setManifestid(307783, "1816684884894923223", 25533130880)
setManifestid(307784, "3401281719433326658", 38577742784)
setManifestid(347150, "4338267348866793457", 304)
setManifestid(347152, "3968766527137329761", 320)
setManifestid(347153, "8805752485552318169", 320)
setManifestid(347154, "2367601758245063172", 10960)
setManifestid(347155, "6694947482485861674", 320)
setManifestid(347890, "9019825025781604845", 352)
setManifestid(351550, "8357497103448333710", 320)
setManifestid(351551, "4993234369582644430", 320)
setManifestid(351552, "443867069664371166", 320)
setManifestid(351553, "8998990461481944590", 432)
setManifestid(351554, "4748821729091936932", 432)
setManifestid(351555, "6960533188296214475", 432)
setManifestid(351556, "9098838434890469410", 496)
setManifestid(351557, "6768511622483632716", 129492432)
setManifestid(351558, "7593285350191767262", 496)
setManifestid(351559, "3297137516582340465", 652737232)
setManifestid(354413, "3458388745384864636", 432)
setManifestid(354425, "7342610577311621078", 432)
setManifestid(354426, "7125000413805663899", 432)
setManifestid(354427, "7423120599132382125", 432)
setManifestid(228984, "2547553897526095397", 13436144)
setManifestid(228990, "1829726630299308803", 100658080)
