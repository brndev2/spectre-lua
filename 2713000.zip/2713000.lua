-- Lua provided by RyzenAPI
-- Game: Resonance: A Plague Tale Legacy

-- MAIN APPLICATION
addappid(2713000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3837640) -- Resonance: A Plague Tale Legacy - Heritage Pack DLC
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2713001, 1, "7085af990ca726e5a5e97ac1acd51bf4f32ba387d0f3d5edb114720e52b536b4")
addtoken(2713000, "17223300556103744127")

-- MANIFESTS / UPDATES
setManifestid(228989, "5753583882400741046")
