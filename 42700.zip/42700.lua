
-- Game: Call of Duty®: Black Ops

-- MAIN APP DEPOTS / PACKAGES
addappid(42700, 1, "f15c6af8ba661ac92e674238a47ffb183335b824a29cdc294e22c832672303a8") --Mainappid Call of Duty®: Black Ops
addappid(42701, 1, "ddd8000d5816ec84893d070556a6649261339998966a01ee2223be068c9f149f") --Main Windows Depot Call of Duty®: Black Ops
addappid(42702, 1, "0a06c6a7e3239813ec8eaa68b3f825792e50e8f9766d7218440f95cafc414df2") --Main Windows Depot Call of Duty®: Black Ops
addappid(42703, 1, "48e008cbcb32413a3e7645bb624908b69f3c45a1e1bd2d288d710120e7db2872") --Main Windows Language Depot English Call of Duty®: Black Ops
addappid(42705, 1, "12ace44104d1b7194c091d35ced64b2eaa19e0fbc3c21c4c6b0196624408ee3a") --Main Windows Language Depot French Call of Duty®: Black Ops
addappid(42706, 1, "01c5172e023bfeda1a5441d6bd640e5b8b8c70b1882ac68d214e1a6ada4a85b8") --Main Windows Language Depot German Call of Duty®: Black Ops
addappid(42707, 1, "4239d3b38cd64b5d20dba2b00d0b170a008574a779a2233da2bf9a8405e165d1") --Main Windows Language Depot Italian Call of Duty®: Black Ops
addappid(42708, 1, "6977051f55833a3bb91c8ca4df029767d7069a9aa15ee46ad2c2233c159b5c86") --Main Windows Language Depot Spanish Call of Duty®: Black Ops
addappid(42709, 1, "765bedbba80d60fb32bd6ece8b768bbcfd0e3c06046aad7f551613c1f485f5cd") --Main Windows Language Depot Russian Call of Duty®: Black Ops
addappid(42711, 1, "f47b3121d84acb57cf36e8a31252de7aaa36d46cabb5025606c25701af1fc9ff") --Main Windows Language Depot Polish Call of Duty®: Black Ops
addappid(42712, 1, "5368e07809c82a9de5bdd7d4367711a499bf3c5aaa8cda2a74eed0ec6692f953") --Main Windows Language Depot Japanese Call of Duty®: Black Ops
addappid(42713, 1, "a1c22f61cab5fbe228ca1e586d0995d1c3ce0443ae89a1b69868fb63b237b459") --Main Windows Language Depot German Call of Duty®: Black Ops
addappid(42714, 1, "5fd131f536d8843c93152e3b86d2488f644cc50b67c0a4f7d3ae27584f0d094c") --Main Windows Depot Call of Duty®: Black Ops
addappid(214631, 1, "904a406f1e717b877cb557516d994c9ec6e8af49fd1e1ba8a92925dd1da16565") --Main Macos Depot Call of Duty®: Black Ops
addappid(214632, 1, "481c1e943f158a88f14c744f2881f80e324eadabcf226af94a694ab798245b8a") --Main Macos Depot Call of Duty®: Black Ops
addappid(214633, 1, "1827c09ead4857e3d99ed07af58f7c32f468381b3594c2be3f0de7c441e239ad") --Main Macos Language Depot English Call of Duty®: Black Ops
addappid(214635, 1, "2ec4aac7f7b604c205cf17bfbff40afc739beb79ba4493e1db6c98151ff4b98e") --Main Macos Language Depot French Call of Duty®: Black Ops
addappid(214636, 1, "ef90f2445f2f952ba7f1dbf12ada65d4c5b7a4f23a2ea0abe0f029ba17a9d797") --Main Macos Language Depot German Call of Duty®: Black Ops
addappid(214637, 1, "6383ae668b25aa3614f8ba35f8ccf6e643a4a6dda535c4683999d6f2450b89ee") --Main Macos Language Depot Italian Call of Duty®: Black Ops
addappid(214638, 1, "f87d21994f2c02b7117e4087e5a2bb480a2bd4454214d173df7d122a85469d0f") --Main Macos Language Depot Spanish Call of Duty®: Black Ops
addappid(214646, 1, "ee8525fdbe70362e66f42974cce4b72d5a3adb9fb15fc3f2384d6f086685ab1a") --Main Macos Depot Call of Duty®: Black Ops
addappid(214648, 1, "2896d470d4d48f43652d59ee4786b54260f01d2b87bebd371adbf80ad4133f78") --Main Macos Depot Call of Duty®: Black Ops
addappid(214649, 1, "7aa1998611367715c053d2f57dcd29ad635b6f7a1abfb012bf95e3ec914974ce") --Main Macos Depot Call of Duty®: Black Ops
addappid(214653, 1, "81046867559a5bc1da7150ddb6f8a0bfd0b30a30f6656da8bd1689b7014bae97") --Main Macos Depot Call of Duty®: Black Ops
addappid(42716, 1, "13ab1ab397e033f161418b426a1085bd18b67f111b9bbb903dd101d8b6579774") --Dlcname Call of Duty: Black Ops - First Strike DLC
addappid(42718, 1, "69820ad69e295d2c9d47c4839e89665e898419aa7b5ee63e616e7f5917813c5a") --Dlcname Call of Duty: Black Ops - Escalation SP DLC
addappid(42719, 1, "9353a6d2a3ee0242e27e0263a2cc813b54199b996cae4649a8fd3e68820f68bd") --Dlcname Call of Duty: Black Ops Rezurrection DLC
addappid(42722, 1, "41ff5db29a861668118f45abadc21bc18576a07e8f08da29528b5eb7167c62a3") --Dlcname Call of Duty: Black Ops - Annihilation DLC
addappid(42723, 1, "9cc78f24c57edd7e0339365d42fe9b39b9893bd24a9fd7ab156315016ac59a90") --Dlcname Call of Duty: Black Ops - Annihilation SP DLC

-- MANIFESTS / UPDATES
setManifestid(42701, "5564723134361260769", 0)
setManifestid(42702, "6257032900290287777", 0)
setManifestid(42703, "8741537774138455205", 0)
setManifestid(42705, "3138932303365817849", 0)
setManifestid(42706, "357347562299132770", 0)
setManifestid(42707, "960178958982048194", 0)
setManifestid(42708, "2954444769787319132", 0)
setManifestid(42709, "4569232414924537110", 0)
setManifestid(42711, "4595024737384945225", 0)
setManifestid(42712, "5149997040663396999", 0)
setManifestid(42713, "6857315315257409107", 0)
setManifestid(42714, "6472729729241488074", 0)
setManifestid(214631, "7802016395965216401", 0)
setManifestid(214632, "2605732980233577166", 0)
setManifestid(214633, "982368564698117322", 0)
setManifestid(214635, "7174585141737681556", 0)
setManifestid(214636, "6061879198934230124", 0)
setManifestid(214637, "7429125894442942724", 0)
setManifestid(214638, "6985602171318889261", 0)
setManifestid(214646, "962139694640373478", 0)
setManifestid(214648, "8215032655708545859", 0)
setManifestid(214649, "4205037187636915696", 0)
setManifestid(214653, "8132945300873862767", 0)
setManifestid(42716, "5219529921410063376", 0)
setManifestid(42718, "1065439930824857999", 0)
setManifestid(42719, "7063395875107468534", 0)
setManifestid(42723, "3361073951409360487", 0)
