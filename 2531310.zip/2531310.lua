-- Lua provided by RyzenAPI
-- Game: The Last of Us™ Part II Remastered

-- MAIN APP DEPOTS / PACKAGES
addappid(2531310, 1, "49f0a72cd4e9ccf4a37166311008ed867fe55dacd8fb669530d449c7acc9bfc1") --Mainappid The Last of Us™ Part II Remastered
addappid(2531311, 1, "f7506952e736e71547c2d3c2c82959438e836c66d5b8b8f3208ccc082f60df23") --Main Windows Depot The Last of Us™ Part II Remastered
addappid(2531312, 1, "60bec6c44987ec1a1d91da8bd7b25f4bbb58f6159b7d7ece95e2f107f7d456a4") --Main Windows Depot The Last of Us™ Part II Remastered
addappid(2531313, 1, "a88758211f172f53efb57ad5c819b9d5f34b0796b44bd876639a09029e6a8089") --Main Windows Depot The Last of Us™ Part II Remastered
addappid(2531314, 1, "3dc1a7d997476f1b4eb3a78f11af1be0d750a14719dc5d5eaeb940bcd44b74e5") --Main Windows Depot The Last of Us™ Part II Remastered
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Share Windows Depot Steamworks Common Redistributables
addappid(3420050) --Dlcname The Last of Us™ Part II Remastered - Pre-purchase Entitlements

-- MANIFESTS / UPDATES
setManifestid(2531311, "4566212634007989287", 76972646960)
setManifestid(2531312, "666389493307802768", 5779502176)
setManifestid(2531313, "4994458262959665537", 30780968432)
setManifestid(2531314, "6262322802969244361", 511580000)
setManifestid(228989, "5753583882400741046", 25108528)
