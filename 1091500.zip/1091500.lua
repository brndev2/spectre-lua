-- Lua provided by RyzenAPI
-- Game: Cyberpunk 2077

-- MAIN APP DEPOTS / PACKAGES
addappid(1091500, 1, "cf941dce25dfe9090877d385fca0ded473ecc1e12a09e28698b5c8dd3c134598") --Mainappid Cyberpunk 2077
addappid(1091501, 1, "fd4524cb30582752f15e4bf01254dbb7b890f58008101a40208cd78fb139d800") --Main Windows Depot Cyberpunk 2077
addappid(1091502, 1, "90dd5a17a45ff0595a7ed6366d0fea078e8c362633ebbe6382c173d736063b72") --Main Windows Language Depot Polish Cyberpunk 2077
addappid(1091503, 1, "b2606cbfc79b86f848e75dbf59afeeae8a1d5c08523111dcdbeace51b69ec48c") --Main Windows Language Depot Russian Cyberpunk 2077
addappid(1091504, 1, "c874647c72c73e87686ecef42bd4c0fbc8e564be98bb0c20c487807c2c4d8d47") --Main Windows Language Depot French Cyberpunk 2077
addappid(1091505, 1, "8382ac2e50bd6c716f748eefe9aa9a7e4ccafe5f4f2d7a19f01e5d5d2d096864") --Main Windows Language Depot Italian Cyberpunk 2077
addappid(1091506, 1, "794d47675f8d91a58528e4b7e0bb347d1c542ccdd48eeda5a796b7c1af663e08") --Main Windows Language Depot German Cyberpunk 2077
addappid(1091507, 1, "ad400264d25291632ad0c35e48e98ae3ada3c411a7ed946bacbdfaa80fd0dd00") --Main Windows Language Depot Spanish Cyberpunk 2077
addappid(1091508, 1, "fa0ebf333c7ac4828a8a38fd9c646543a872965d3bf1b5e205fa176dc1e93337") --Main Windows Language Depot Japanese Cyberpunk 2077
addappid(1091509, 1, "987c3b4b920a2258661e62065089d398fcc2412b300355c47a2655b4b373fafa") --Main Windows Language Depot Schinese Cyberpunk 2077
addappid(1460470, 1, "97d6dfacfdc6ba0678277cfbdc4f38b561807a3fb8679513411c7b9e819195b3") --Main Windows Language Depot Koreana Cyberpunk 2077
addappid(1460471, 1, "20f9808b7948ce1d4b7b16d660e745ce5f251bd0e40c18d8a4072d7f944eb56e") --Main Windows Language Depot Brazilian Cyberpunk 2077
addappid(1460472, 1, "4a09fae0555b97d34d444aedd46d8cd47c11ab25628c614721745c8a3a849c67") --Main Macos Depot Cyberpunk 2077
addappid(1460473, 1, "64626ac37340f33f4b81bb2c265d17c61f4fad0b9563bb7b203043296046d2e6") --Main Macos Language Depot Polish Cyberpunk 2077
addappid(1460474, 1, "99ea9ff03413e3248190086be885c4d1737381b7f0f556a1a454cdf978e6c920") --Main Macos Language Depot Russian Cyberpunk 2077
addappid(1460475, 1, "fb5c6a7f869e491c703a7f492c9ade3fe005c518641889a62b16bc6906f799dc") --Main Macos Language Depot French Cyberpunk 2077
addappid(1460476, 1, "61fdd193af9b99cedd7e906207aa0226e707f8284c65bd101c576e1d76271f7a") --Main Macos Language Depot Italian Cyberpunk 2077
addappid(1460477, 1, "7d2ad45d3773bf1408ae5c1a830316b4b8e9642ddac137a9f6c222621b922127") --Main Macos Language Depot German Cyberpunk 2077
addappid(1460478, 1, "a2da1ad1617b6d8f0063b3d7e1bfd3a05a7f1fd2c52ec2ae6143de6a1b30144d") --Main Macos Language Depot Spanish Cyberpunk 2077
addappid(1460479, 1, "7f2d2390ec4b34101279050df7906f9cdb6945d65cb83d41406b90efc6d4820b") --Main Macos Language Depot Japanese Cyberpunk 2077
addappid(2060311, 1, "ef94a15784ab7bc81ddec255b4f2af287543f9dd64edc1210faa708302ef4644") --Main Macos Language Depot Schinese Cyberpunk 2077
addappid(2060312, 1, "f41e81056d725072d0a92b750b9f7156fc37d87f82cec6b5cc9a6e1907c25724") --Main Macos Language Depot Koreana Cyberpunk 2077
addappid(2060313, 1, "e4840e97b028bf1877c6173d714b377621610d8caba91bf5077da9ce6758ae43") --Main Macos Language Depot Brazilian Cyberpunk 2077
addappid(2060314, 1, "ff813dcc60265582f65f61e4ab399689124c32d7147dc5add8ccc9cb3077310e") --Main Macos Depot Cyberpunk 2077
addtoken(1495710, "13440227389371067611")
addappid(1495710, 1, "d1eee983c6b6dc175c3ec89ae337fe4e4435d19bf689ed1607e19f0887ca1e3c") --Dlcname Cyberpunk 2077 Bonus Content
addappid(2060310, 1, "45cf0829a4dae87f0f1b263c92df30079111d1dd697bb87d6830f21e04fdf8a0") --Dlcname Cyberpunk 2077 REDmod
addappid(2138330, 1, "0b2b89913e185ab0ac452b5af584c482d5a8c6f34b7b32ae2dda130deaab64bd") --Dlcname Cyberpunk 2077: Phantom Liberty
addappid(2138331, 1, "2555f9afe152d9355bbc8153ed96c38750b8bbe66724062fde11810dbf132693") --Dlc Windows Language Depot German Cyberpunk 2077: Phantom Liberty
addappid(2138332, 1, "4c64a4a0b1cd40244001e3d86e6fc19208ee6f1367cd117683860fcfe9e08dcb") --Dlc Windows Language Depot Spanish Cyberpunk 2077: Phantom Liberty
addappid(2138333, 1, "7991a1134455aead3222a58b1246e836804a0ef11faef0284867c29d77d23945") --Dlc Windows Language Depot French Cyberpunk 2077: Phantom Liberty
addappid(2138334, 1, "7cf1934dfe03948c22b65d11c4b0df6fe4bb6f05c0b76fc6c240b730cb62c73d") --Dlc Windows Language Depot Italian Cyberpunk 2077: Phantom Liberty
addappid(2138335, 1, "6388e0552ce0fc948e5c93e23902afa0ba9315d78f9eb491422abdc97b390409") --Dlc Windows Language Depot Japanese Cyberpunk 2077: Phantom Liberty
addappid(2138336, 1, "c318bdc3350aad3f756cadb68d2dde3954e60869c003ad15d150e0f5d95bdad9") --Dlc Windows Language Depot Koreana Cyberpunk 2077: Phantom Liberty
addappid(2138337, 1, "f9d3075d5d20d353263175bd5a682ff396fc3e2e59836a39e018ac81200c505f") --Dlc Windows Language Depot Polish Cyberpunk 2077: Phantom Liberty
addappid(2138338, 1, "6bf9c69492004a9e232ab7c90dbdafae3ae3364cccdf4104df98f3fd02e4ddb7") --Dlc Windows Language Depot Brazilian Cyberpunk 2077: Phantom Liberty
addappid(2138339, 1, "0d34fa3f0439c9b355882e4e366c4ff89f4e17d2cc2605a05f7473c48ca93bee") --Dlc Windows Language Depot Russian Cyberpunk 2077: Phantom Liberty
addappid(2224070, 1, "13af5172058a27f8523f2caf0b4378c8dc58adf507ff3b8320ee6292ef2db899") --Dlc Windows Language Depot Schinese Cyberpunk 2077: Phantom Liberty
addappid(2224071, 1, "317b5b3562f0a547d859f8203880c860e8d47727942c50486f9810b6bee43e93") --Dlc Macos Language Depot German Cyberpunk 2077: Phantom Liberty
addappid(2224072, 1, "b98c868ca11a3cb0052c5cb5fc6ed67e755c7f5da8dd080c958c6154eda17f80") --Dlc Macos Language Depot Spanish Cyberpunk 2077: Phantom Liberty
addappid(2224073, 1, "43531dc1bf07842e223ac2591bc263b4ce37090bc89d632b94baa4effde4de20") --Dlc Macos Language Depot French Cyberpunk 2077: Phantom Liberty
addappid(2224074, 1, "8a45b53465567f0e423a2fb234f868faa70b7b827aa1d4bca9eb1169b7e63a46") --Dlc Macos Language Depot Italian Cyberpunk 2077: Phantom Liberty
addappid(2224075, 1, "aa69ea92143a543978677d384d5ed2ab574470c137cf691ad2de2125e9d0eb9e") --Dlc Macos Language Depot Japanese Cyberpunk 2077: Phantom Liberty
addappid(2224076, 1, "c793077de4603ece9521f298182259790c92ea2933a854e3b8fc2729c15791df") --Dlc Macos Language Depot Koreana Cyberpunk 2077: Phantom Liberty
addappid(2224077, 1, "f788663dc6d2f5c417e51a5b1a22356e2c3c3a60b85d89672f0216517aa92e73") --Dlc Macos Language Depot Polish Cyberpunk 2077: Phantom Liberty
addappid(2224078, 1, "7ee88193e5b45b787242dfef113c89d6efac43c9ef159c362f44485102488194") --Dlc Macos Language Depot Brazilian Cyberpunk 2077: Phantom Liberty
addappid(2224079, 1, "ea8df3c3b262a96dd8dd06b0d3ab8393fa170771edee5f40a240488e3edf913b") --Dlc Macos Language Depot Russian Cyberpunk 2077: Phantom Liberty
addappid(2224080, 1, "0cb8af78efc733ca46c7b5a0b9d520b2002b5860fd70f052d59b67dc1112e3ea") --Dlc Macos Language Depot Schinese Cyberpunk 2077: Phantom Liberty
addappid(2224089, 1, "284e2db9b686f24646644f365f81f5447d2b26d1363163df229904c8378a0015") --Dlc Macos Depot Cyberpunk 2077: Phantom Liberty
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") --Share Windows Depot Steamworks Common Redistributables
addappid(2441600) --Dlcname Phantom Liberty: Quadra "Vigilante" Pre-Order Bonus

-- MANIFESTS / UPDATES
setManifestid(1091501, "3389237510439361019", 62838340624)
setManifestid(1091502, "819305496055337333", 4656225472)
setManifestid(1091503, "2051822335481947109", 5144290784)
setManifestid(1091504, "7478488130966967410", 4780595408)
setManifestid(1091505, "7982214908117080286", 4964476112)
setManifestid(1091506, "2059269590710419725", 4864100640)
setManifestid(1091507, "5073153400365828217", 5214635968)
setManifestid(1091508, "8836038990327543024", 4663803792)
setManifestid(1091509, "2202736442745644704", 4657962720)
setManifestid(1460470, "4839420595466808435", 4789899584)
setManifestid(1460471, "2293639687853156805", 4905018992)
setManifestid(1460472, "5981221262164233110", 61794941840)
setManifestid(1460473, "4454430973432607690", 4687063296)
setManifestid(1460474, "7938674529027331922", 5176848880)
setManifestid(1460475, "7853535993200244780", 4812635280)
setManifestid(1460476, "498796436523263654", 4997786128)
setManifestid(1460477, "1896916863970882797", 4895626240)
setManifestid(1460478, "3309239801554497084", 5247130944)
setManifestid(1460479, "6745659364404681444", 4692579392)
setManifestid(2060311, "4326308133756950004", 4688193904)
setManifestid(2060312, "8947960492874992155", 4819903584)
setManifestid(2060313, "1938057724979497570", 4936649232)
setManifestid(2060314, "965414302594932117", 52846304)
setManifestid(2060310, "2810178366748735393", 22920704)
setManifestid(2138330, "1003893636455474164", 23795013648)
setManifestid(2138331, "7557611394831771970", 1962164592)
setManifestid(2138332, "7728733908936856189", 1705043360)
setManifestid(2138333, "2737235465048019797", 1626905440)
setManifestid(2138334, "2255167949129647656", 1643806176)
setManifestid(2138335, "6491696797696369813", 1814246432)
setManifestid(2138336, "8637009798751881938", 1573838992)
setManifestid(2138337, "2512706444417470881", 1698309872)
setManifestid(2138338, "6821671836788372554", 1729239728)
setManifestid(2138339, "7556060123277495603", 1524328640)
setManifestid(2224070, "8906180928185088202", 1782998752)
setManifestid(2224071, "8308591706303082171", 1968963568)
setManifestid(2224072, "2650640366998881299", 1712654528)
setManifestid(2224073, "128847074090854083", 1634613808)
setManifestid(2224074, "2438632982641321122", 1651266080)
setManifestid(2224075, "4943340702183225440", 1821059232)
setManifestid(2224076, "5075323111781204317", 1580643936)
setManifestid(2224077, "3364673074736515968", 1705886384)
setManifestid(2224078, "1790681978238440284", 1737190352)
setManifestid(2224079, "8450842337059471618", 1532175952)
setManifestid(2224080, "1116267346816464113", 1790028576)
setManifestid(2224089, "2868368683526045092", 23427312080)
setManifestid(228988, "6645201662696499616", 22411856)
setManifestid(1091500, "6979118451408560866")
