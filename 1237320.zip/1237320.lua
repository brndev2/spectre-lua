-- Lua provided by RyzenAPI
-- Game: Sonic Frontiers

-- MAIN APP DEPOTS / PACKAGES
addappid(1237320, 1, "3ebe9642492771d61117fd46f7dda3f5802c6376580b7f8453af96109fac6f27") --Mainappid Sonic Frontiers
addappid(1237321, 1, "9c57e01f36d7bf7a77b07678b08a0e690d785dfbcd9a421ae1fc2157741b5ccd") --Main Windows Depot Sonic Frontiers
addappid(2079301, 1, "db37953f414051736b6e659e9146fa2e081148a94633fbea635610f79d6588da") --Dlcname Sonic Frontiers: Explorer's Treasure Box
addappid(2089730, 1, "dfb354863019c75a8143f9e7073ed589df096057283247fe5e16c1c6225667f2") --Dlcname Sonic Frontiers: Monster Hunter Collaboration Pack
addappid(2089733, 1, "3dedee464853a2702ce024319deb87d57c6e2e404a328bce05f71b18a2649faf") --Dlcname Sonic Frontiers: Holiday Cheer Suit
addappid(2089840, 1, "cf0ee3bde87a208b2bf9425b695b287a2997de71728df89f826fca1667197f85") --Dlcname Sonic Frontiers: Sonic Adventure 2 Shoes
addappid(2093240) --Dlcname Sonic Frontiers: Digital Art Book with Mini Digital Soundtrack
addappid(2093241, 1, "9eac17d35c7a4d92c2bc39bbfcd5a64c61df1d4aed6c5dc7bad49f962d4780bf") --Dlc Windows Depot Sonic Frontiers: Digital Art Book with Mini Digital Soundtrack
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables

-- MANIFESTS / UPDATES
setManifestid(1237321, "2773324310090316887", 31113397296)
setManifestid(2079301, "3849979216096899603", 11743408)
setManifestid(2089730, "3889377523269958120", 12785456)
setManifestid(2089733, "5603185428396252058", 1777440)
setManifestid(2089840, "71486794841630932", 3285616)
setManifestid(2093241, "5565202849344929598", 637718400)
setManifestid(228988, "6645201662696499616", 22411856)
setManifestid(228990, "1829726630299308803", 100658080)
