-- Lua provided by RyzenAPI
-- Game: DOOM: The Dark Ages

-- MAIN APP DEPOTS / PACKAGES
addappid(3017860, 1, "ce570e5aa3168b1e9c8d2004a3b93db4c11a44cf8b9a99158ae4c1baf9384dbb") --Mainappid DOOM: The Dark Ages
addappid(3017862, 1, "b537907a613fd29911d2e311eb41fd2f0b309324601b0ef164c8520562eac290") --Main Windows Depot DOOM: The Dark Ages
addappid(3017863, 1, "0c010bdf1623542793fb5765875c715494c4a6c78856f75c124aa7d31f3021cd") --Main Windows Depot DOOM: The Dark Ages
addappid(3017864, 1, "35f0d11b6d2b729dd8e5f50a21e7b0300e8d6b79fc6ba487f4198ca6d3402c0d") --Main Windows Depot DOOM: The Dark Ages
addappid(3017865, 1, "558521d6ef4cac7a1318bb55268dc878b72482482691e7791ea81bff06c73694") --Main Windows Depot DOOM: The Dark Ages
addappid(3017866, 1, "cc9112a06785fd0d7f6e24a50702f1f71e655e35caf8fb3ea09f6036680c0fe4") --Main Windows Depot DOOM: The Dark Ages
addappid(3017867, 1, "8ffa78f10846725bed8d48d1a182cf4088f770691c44561b2d167f84fdc60789") --Main Windows Depot DOOM: The Dark Ages
addappid(3017868, 1, "fb3bda82e733857d05419dce15179a1aa642b840af21ef69520346fe8a00e20e") --Main Windows Depot DOOM: The Dark Ages
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
addappid(3363930) --Dlcname DOOM: The Dark Ages - Preorder Content
addtoken(3363930, "3317585234173034770")
addappid(3363940) --Dlcname DOOM: The Dark Ages - Premium Content
addtoken(3363940, "4257299237979279538")
addappid(3469450) --Dlcname DOOM: The Dark Ages | Revelations
addappid(3698350) --Dlcname DOOM: The Dark Ages - Premium Upgrade
addtoken(3698350, "553470768921816577")

-- MANIFESTS / UPDATES
setManifestid(3017862, "7466449196753546769", 167062032)
setManifestid(3017863, "3860369781994465240", 352)
setManifestid(3017864, "7054043744589518599", 11825466528)
setManifestid(3017865, "6508691013012284956", 0)
setManifestid(3017866, "51450828051076476", 288)
setManifestid(3017867, "7998384974670192918", 90173392752)
setManifestid(3017868, "8320539347038966589", 20571120)
setManifestid(228989, "5753583882400741046", 25108528)
setManifestid(228990, "1829726630299308803", 100658080)
