-- Game: Grand Theft Auto IV: The Complete Edition

-- MAIN APP DEPOTS / PACKAGES
addappid(12210, 1, "f44e969edd0de29b860cfcf087e0ddd768dad993f3ff98c50c9a394ca223f04b") --Mainappid Grand Theft Auto IV: The Complete Edition
addappid(12211, 1, "155186d97af14c948ac35351ac345c108046167384eb2b898802f158bfd111b4") --Main Windows Depot Grand Theft Auto IV: The Complete Edition
addappid(12212, 1, "63df369c3038e5c927f585fc81b41f5b669795976ac9af4d27a2add6c57733ca") --Main Windows Depot Grand Theft Auto IV: The Complete Edition
addappid(12213, 1, "e927e10529530ef0a1798c945c7fea9d3a4bd8cb2bac061587c193afbe0dfeec") --Main Windows Language Depot English Grand Theft Auto IV: The Complete Edition
addappid(12214, 1, "f47f42a9df6c82ac4c134478cd1a0c95bdb32f686a3c4033ee8b9735c3999529") --Main Windows Language Depot French Grand Theft Auto IV: The Complete Edition
addappid(12215, 1, "70a582f0d5f9cbf610ccbac1a905c7d5c8f0f3b420412ee754779141d9a89e77") --Main Windows Language Depot Italian Grand Theft Auto IV: The Complete Edition
addappid(12216, 1, "ef7603bd0f512678f2832b71bcb340b950fd5d8ed5f52e0129300538727d1787") --Main Windows Language Depot German Grand Theft Auto IV: The Complete Edition
addappid(12217, 1, "050c5432482073005c36629ad7372baeafb6d1f63b6b8175936feb4ad8521d1c") --Main Windows Language Depot Spanish Grand Theft Auto IV: The Complete Edition
addappid(12218, 1, "3446117408a17195591f5a98c1f64d2ca9a49dcdeb93a90fec8ceb63cb1cf249") --Main Windows Depot Grand Theft Auto IV: The Complete Edition
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
addappid(1899671, 1, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b") --Share Windows Depot RGL/SC

-- MANIFESTS / UPDATES
setManifestid(12211, "8070600747380932868", 14646179360)
setManifestid(12212, "5029883714475696364", 6129658416)
setManifestid(12213, "7959739752369022030", 33147360)
setManifestid(12214, "8513070578700495865", 31457616)
setManifestid(12215, "5596831668192471551", 31629552)
setManifestid(12216, "716802607004606457", 31339184)
setManifestid(12217, "703090685957058760", 31649600)
setManifestid(12218, "5435507331887440070", 6397056)
setManifestid(228984, "2547553897526095397", 13436144)
setManifestid(228990, "1829726630299308803", 100658080)
setManifestid(1899671, "3914969219305676290", 209058416)
