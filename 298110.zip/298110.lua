addappid(298110, 1, "86b92bbc40842cc480a3a99d81c185a4c05b1c15e0837a4cf7ee3ff79a9570a1") --Mainappid Far Cry® 4
addappid(298111, 1, "90765df7a812f66db8794bd7b41b398e9b12fe77ec22caaff1442644d2c2c91d") --Main Windows Depot Far Cry® 4
setManifestid(298111, "1142172031228046975", 19856828096)
addappid(298112, 1, "4f2126199ab0506f24ed8517d6b0e0c2ecf3a5cf4adbb2e5b32efbf21f3bb2e8") --Main Windows Depot Far Cry® 4
setManifestid(298112, "6331152839583468439", 4620394224)
addappid(298113, 1, "e524b5855fe79757f864359e1de9606d4a0ab23ecd59b79f2af270bd97f497c8") --Main Windows Depot Far Cry® 4
setManifestid(298113, "5328801845298185678", 4697681280)
addappid(298114, 1, "2218dbe36d21dd99bf8e46cbf5cb8e9c91897c36983a14363f38dd29d82e94d4") --Main Windows Depot Far Cry® 4
setManifestid(298114, "2463208696266802422", 20967034016)
--Dlcname Far Cry 4 - Escape From Durgesh Prison - Content
addappid(324341, 1, "0a4894abdd94b40c7464d6beced29025b9b2c3b1476d44fdff2697e82edb34a9") --Dlcname Far Cry 4 - Escape From Durgesh Prison - Content
setManifestid(324341, "3810704983363922262", 1876778368)
--Dlcname Far Cry® 4 – Overrun
addappid(324343, 1, "8bcb7ae406c8a5325315decbe096d6b0afecf265d66514a10a1fe242be970690") --Dlcname Far Cry® 4 – Overrun
setManifestid(324343, "8840893055567759529", 934308640)
--Dlcname Far Cry 4 - Valley of the Yetis
addappid(324344, 1, "47c247776a41ae1192804e89b02b35c7567a9f87b280d3e49bab395db669e1da") --Dlcname Far Cry 4 - Valley of the Yetis
setManifestid(324344, "5351965743619922824", 1980908704)
--Share Depots
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228983, "8124929965194586177", 19214528)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") --Share Windows Depot Steamworks Common Redistributables
setManifestid(229004, "5220958916987797232", 70811632)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") --Share Windows Depot Ubisoft Connect PC Client
setManifestid(1716751, "686731643572352019", 264401856)
addappid(324340) --Dlcname Far Cry 4 Season Pass
addtoken(324340, "15952514768522473497")
addappid(324342) --Dlcname AppID 324342
addtoken(324342, "8735670379144936627")
addappid(332220) --Dlcname Far Cry 4 Preorder (RoW) - Uplay Activation
addappid(332221) --Dlcname Far Cry 4 (RoW) - Uplay Activation
addappid(332222) --Dlcname Far Cry 4 Gold (RoW) - Uplay Activation
addappid(332223) --Dlcname Far Cry 4 Preorder (RU) - Uplay Activation
addappid(332224) --Dlcname Far Cry 4 (RU) - Uplay Activation
addappid(332225) --Dlcname Far Cry 4 Gold (RU) - Uplay Activation
addappid(332226) --Dlcname AppID 332226
addappid(332227) --Dlcname AppID 332227
addtoken(332227, "1463951447634841736")
addappid(332228) --Dlcname AppID 332228
addappid(332229) --Dlcname Far Cry 4 Season Pass - Uplay Activation
addappid(332230) --Dlcname Far Cry 4 Preorder (IN) - Uplay Activation
addappid(332231) --Dlcname Far Cry 4 (IN) - Uplay Activation
addappid(332232) --Dlcname Far Cry 4 Gold (IN) - Uplay Activation
addappid(338620) --Dlcname Far Cry 4 - Escape From Durgesh Prison
addappid(343700) --Dlcname Far Cry 4 - Escape From Durgesh Prison - Uplay activation
addappid(345910) --Dlcname AppID 345910
addtoken(345910, "1406313721972257350")
addappid(348080) --Dlcname Far Cry 4 - overrun - Uplay activation
addappid(353870) --Dlcname Far Cry 4 - Valley of the Yetis - Uplay Activation