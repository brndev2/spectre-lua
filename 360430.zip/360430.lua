-- Lua provided by RyzenAPI
-- Game: Mafia III: Definitive Edition

-- MAIN APP DEPOTS / PACKAGES
addappid(360430, 1, "8a15e71b4229596d8fbe53dd9d93bf186098f5ec26e35c8f431940e0e9837349") --Mainappid Mafia III: Definitive Edition
addappid(360431, 1, "4a3e72723286eab2b8e99756608b5e7e189945dac142d4db09e2641bcc60eae8") --Main Windows Depot Mafia III: Definitive Edition
addappid(360432, 1, "1244262974460b4777d46674d5b9c0b4562810f162bf0dd526d29db46cfd6f40") --Main Windows Depot Mafia III: Definitive Edition
addappid(360438, 1, "9cc9b741c2bf74a35787dab0db3c733085d867eb1b60ae5f2f5ddce99c3facdd") --Main Macos Depot Mafia III: Definitive Edition
addappid(360439, 1, "8468c3e4cc98f66cdb0829e2da136c7ec2a00d2ccffc2c6c6753040cab176213") --Main Macos Depot Mafia III: Definitive Edition
addappid(511890, 1, "629e0b865b1822be42ca68d57c673a35661ce023442fded770e0388c63355c8d") --Dlcname Mafia III: Judge, Jury and Executioner Weapons Pack
addappid(511898, 1, "fcbcd4dd944fbac6e43ad4e5a24b5b49232353293a7afa5cdf2a9340b213badf") --Dlc Macos Depot Mafia III: Judge, Jury and Executioner Weapons Pack
addappid(511892, 1, "d42487684b1cfe24dda0c1b58dee70794bf0ff8e154d4c780e2b1b2fa06dd24f") --Dlcname Mafia III: Family Kick-Back Pack
addappid(511899, 1, "6b42977a58e581138a7b83a7b0f376971cbef0938280a627ad62d0af4ad32374") --Dlc Macos Depot Mafia III: Family Kick-Back Pack
addappid(598020, 1, "bfbf614d0bf361b7a9a01c2131b1562dcda664bdaf0f0cf3327e6a00dfbdd4f5") --Dlcname Mafia III: Faster, Baby!
addappid(598029, 1, "d31679d286f13684adf1234b8418621ea8722da3ab886b992ae6f8dbf539576b") --Dlc Macos Depot Mafia III: Faster, Baby!
addappid(598021, 1, "84b841715b6a1064475d21d2ee14302cdbf40ff3bbdd0f6a8c2382f7bd3355fe") --Dlcname Mafia III: Stones Unturned
addappid(598022, 1, "f2d9fd1f15e2ee238b32f524799d913c8166a4d09498a68d9451a78c44d8af3f") --Dlcname Mafia III: Sign of the Times
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") --Share Windows Depot Steamworks Common Redistributables
addappid(1523211, 1, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b") --Share Windows Depot AppID 1523210
addappid(511891) --Dlcname Mafia III: Season Pass

-- MANIFESTS / UPDATES
setManifestid(360431, "3532314879832368080", 49408644624)
setManifestid(360432, "8773375485519535397", 843354736)
setManifestid(360438, "2467089648767970112", 44613355168)
setManifestid(360439, "2746032780764026926", 58594992)
setManifestid(511890, "454834834847228076", 1072)
setManifestid(511898, "5304880233194808812", 1072)
setManifestid(511892, "992891886538164515", 1216)
setManifestid(511899, "9009976994094612939", 1216)
setManifestid(598020, "8199463638102391193", 2745655024)
setManifestid(598029, "4685441623310950674", 2574361920)
setManifestid(598021, "5920706206030683877", 1766903216)
setManifestid(598022, "4632933338714674769", 1046332048)
setManifestid(228986, "8782296191957114623", 23045488)
setManifestid(228990, "1829726630299308803", 100658080)
setManifestid(229004, "5220958916987797232", 70811632)
setManifestid(1523211, "5488617169383930545", 128)
