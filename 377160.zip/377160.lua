-- Lua provided by RyzenAPI
-- Game: Fallout 4

-- MAIN APP DEPOTS / PACKAGES
addappid(377160, 1, "dfc5c67e0d9c0c6e751841cfbf3871dfc7e74c7ae74201ef1fc44433ced47ea6") --Mainappid Fallout 4
addappid(377161, 1, "cf55ff4eb121541f33f811d2d6ea719ca07d31a0fd0538d919681f88d65f4ded") --Main Windows Depot Fallout 4
addappid(377162, 1, "9359116457874510935256b2afa0ee9a9a9f9d5f2f2f73ebd4572c10a12151ed") --Main Windows Depot Fallout 4
addappid(377163, 1, "f03ba1f9873bd21c81244e645173f5af3e91835b639d3844e9056884e8adec69") --Main Windows Depot Fallout 4
addappid(377164, 1, "56581e69491ba1f0201475f72b87e17a3cc811af69f607b347a2e4ae9186bd91") --Main Windows Language Depot English Fallout 4
addappid(377165, 1, "aaa48ad43bfc6f4d98f66db3d51885094a8a76a000a631accd7b31b77e60551f") --Main Windows Language Depot French Fallout 4
addappid(377166, 1, "3b2ed944d6d06581d05a9e39624d2ec0072a0e1874f68bcbd3d79720f107b8c6") --Main Windows Language Depot German Fallout 4
addappid(377167, 1, "8b387ace74796c278318d32849b1166cc5e8cf903737fd373283bfc378b13c03") --Main Windows Language Depot Italian Fallout 4
addappid(377168, 1, "989db8879bc65a93a05f637822e2f8f5ae6bdba3e8c4deabe2de7537d8c5dd90") --Main Windows Language Depot Spanish Fallout 4
addappid(393880, 1, "be371c5fd2f17bb744a123119f2183e056f126efe4840e31ef78c5910c6dde15") --Main Windows Language Depot Polish Fallout 4
addappid(393881, 1, "7ea60442ab1956fbaad239a5ad4689865408d828dd33f61b2a77000432e93532") --Main Windows Language Depot Russian Fallout 4
addappid(393882, 1, "dbdd032f2bba74024f7e997d9e3d6f887d807d93079e4351695bb5ee6471e1cf") --Main Windows Language Depot Brazilian Fallout 4
addappid(393883, 1, "c42701914a636c3fff6384296da4d88fdd40e1bda656e28f7aaa2a1e9c7bd4ff") --Main Windows Language Depot Tchinese Fallout 4
addappid(393884, 1, "a67dc17de7b3199a0ff3856ce2e26674c4f27e3c11584b8bbafe75a8742e19ec") --Main Windows Language Depot Japanese Fallout 4
addtoken(435870, "17969553131570605880")
addappid(435870, 1, "fd023abf6834589abe5b821cacd216be0e8d5a9e9721ab8ebe31dcf701c0de7d") --Dlcname Fallout 4 - Automatron
addappid(404091, 1, "3dd27f593b9f0930a8a3b98b55a389b64f2fa4f9bf5ff34ba6005bb3bb2cb845") --Dlc Windows Language Depot Japanese Fallout 4 - Automatron
addappid(435871, 1, "aacc0920e891440700301b37b1cb8b69e1d5cf1b32a92922b10278b19660d804") --Dlc Windows Language Depot English Fallout 4 - Automatron
addappid(435872, 1, "01f0ec6bf3f63f16575ea6641475c57d01d3b8dc20a3c39cd8ceacf79f588c44") --Dlc Windows Language Depot French Fallout 4 - Automatron
addappid(435873, 1, "599277603b3eda83869261b13e66050cc02e26f31f1fe08c8ec5900b64062334") --Dlc Windows Language Depot German Fallout 4 - Automatron
addappid(435874, 1, "4c5e3baa3d3e4e68a04f56628c8cbd33a0596bfa535e85e901270eb7b14af989") --Dlc Windows Language Depot Italian Fallout 4 - Automatron
addappid(435875, 1, "814fa019490218c830186ed12559f0eabe59d24f3bb7e7d3522d358679330c71") --Dlc Windows Language Depot Spanish Fallout 4 - Automatron
addappid(435876, 1, "a13a6971709630b53e7ff6229bda149bb26c32db6be18ba9b5ee3bf2e4b3474d") --Dlc Windows Language Depot Polish Fallout 4 - Automatron
addappid(435877, 1, "3d24c99bdda19313f7a226584b9e85e89dd7f94cab42186d7748939d09c9de18") --Dlc Windows Language Depot Russian Fallout 4 - Automatron
addappid(435878, 1, "f8d3fefa3a0dc6478c310aac162f0188fae8a6a2882b3f217f1023409ce2d999") --Dlc Windows Language Depot Brazilian Fallout 4 - Automatron
addappid(435879, 1, "2ee9553b4473c82551838b6b6414bc2fbe36c2e95a6e0067dd00043d982d97f4") --Dlc Windows Language Depot Tchinese Fallout 4 - Automatron
addtoken(435880, "17715695874793604951")
addappid(435880, 1, "13b5b5f94eefcc14fabb0b56123feb7e52721ab1102049bc32bfcd3e725019e8") --Dlcname Fallout 4 - Wasteland Workshop
addappid(435881, 1, "4731dc8b04e4489853ae1c53e3acc9f0a01e825b40b7fc9a4a42caba6ac1b827") --Dlcname Fallout 4 - Far Harbor
addappid(404092, 1, "5c000d51b29a21009a0c34676736af0489b84ff04d95ffaad51b2e08edb11cbc") --Dlc Windows Language Depot Tchinese Fallout 4 - Far Harbor
addappid(404093, 1, "86e7040eb97d187726bd865bf08c7448cd80b7f8f24aebf859517b949bc92b96") --Dlc Windows Language Depot Japanese Fallout 4 - Far Harbor
addappid(435882, 1, "104a86e91eee18c19b3510432a7af8070a1f8f1c4503eb14bff5b4403277b58c") --Dlc Windows Language Depot English Fallout 4 - Far Harbor
addappid(435883, 1, "86da5aac15b38aabc81cb05fd6a22ed668c8c0df9f59a970363bf07ec3c02a1d") --Dlc Windows Language Depot French Fallout 4 - Far Harbor
addappid(435884, 1, "600d918749fe3c1b474a4f35006093da7b776c1d22f77631c54c79178d9d7d04") --Dlc Windows Language Depot German Fallout 4 - Far Harbor
addappid(435885, 1, "5ec02acad9ff3460418cd29f03fc1dbee198928c39480eaad5893a9d1f1b19fd") --Dlc Windows Language Depot Italian Fallout 4 - Far Harbor
addappid(435886, 1, "0252bc7861d5e8f23b05868f9c426858bf394c1cb31d55a1d8698d38fa6e51d6") --Dlc Windows Language Depot Spanish Fallout 4 - Far Harbor
addappid(435887, 1, "2be8d5ae343e13852b44df46e61c82d40ca24cbfcff9c5c47ede9f67c138128f") --Dlc Windows Language Depot Polish Fallout 4 - Far Harbor
addappid(435888, 1, "6694db4f8104eddbfe57cff2b59f32d4bf8f5dde0e53cdb14cb5b72c1e27605f") --Dlc Windows Language Depot Russian Fallout 4 - Far Harbor
addappid(435889, 1, "7ee24d3ddff2cced1b3db1dde5a525b2e425b82c95de0c85fcce2f628dbe94a7") --Dlc Windows Language Depot Brazilian Fallout 4 - Far Harbor
addappid(480630, 1, "6953ddb6e356d189e09f0b50251b037ac8c81936dbc4565e090d496c0be8b873") --Dlcname Fallout 4 - Contraptions Workshop
addappid(480631, 1, "a88d4ec336a1ba15e5717651684218f13a243e72bce1b32b71b7f31c53fb5237") --Dlcname Fallout 4 - Vault-Tec Workshop
addappid(393885, 1, "d9971261bad1c0f7aefc8827764b4219e13aadb91470775669b513c82c15e187") --Dlc Windows Language Depot English Fallout 4 - Vault-Tec Workshop
addappid(393886, 1, "e0c2c543eab3d78f84738d8aa943f6b11459da98c357eadd718eaf4f2adde66a") --Dlc Windows Language Depot French Fallout 4 - Vault-Tec Workshop
addappid(393887, 1, "e10a31c16258cb554f492a5e621311ac36ec9dc81d3c1e130763b4143280d192") --Dlc Windows Language Depot German Fallout 4 - Vault-Tec Workshop
addappid(393888, 1, "70bfc01d0911594548dcb656c8c812377d1ebe7e77388a69c6578af1f9c929fb") --Dlc Windows Language Depot Italian Fallout 4 - Vault-Tec Workshop
addappid(393889, 1, "86ef9bb8655900e4d97dc8296e267e88f864810ed6f68726643b16ab404ea584") --Dlc Windows Language Depot Spanish Fallout 4 - Vault-Tec Workshop
addappid(393890, 1, "a8fd2b3208528a9b01591d8ac5b602d9cf9e7e6d4dc2965252737af6729d0dd9") --Dlc Windows Language Depot Polish Fallout 4 - Vault-Tec Workshop
addappid(393891, 1, "08d7dbf14f3d6009b1b2b0ec03018fef84715f166df545508f7c98271759bd01") --Dlc Windows Language Depot Russian Fallout 4 - Vault-Tec Workshop
addappid(393892, 1, "3d75cb3eef28d199fcb66a190f1be5b8b2e7cf4f3fbcf5dc7836b4f20596d97e") --Dlc Windows Language Depot Brazilian Fallout 4 - Vault-Tec Workshop
addappid(393893, 1, "fdbad14eaa02a4794dcdf2cfb2737262057045d7dd0e97647a5aaab843c7491c") --Dlc Windows Language Depot Tchinese Fallout 4 - Vault-Tec Workshop
addappid(393894, 1, "6b64b629795dde4903ab8c5bef8f4222d1d67849e677d6f9b0941c859767d13f") --Dlc Windows Language Depot Japanese Fallout 4 - Vault-Tec Workshop
addappid(490650, 1, "587e38c20a8f18f3825470a5c22ebd0c2c3cb86df75f3b8fed4bfe3c0dcfe35a") --Dlcname Fallout 4 - Nuka-World
addappid(377169, 1, "1d098c24441e5a8a452c9f364f13a8e141956089d1631f12d969e38b405588f6") --Dlc Windows Language Depot Italian Fallout 4 - Nuka-World
addappid(393895, 1, "89cc7d9d61ec6f74626b9b2dc202339a17fed368450352256d6876d8e26ff7ca") --Dlc Windows Language Depot English Fallout 4 - Nuka-World
addappid(393896, 1, "92ede763b94b9b539344f426567b63ceb14eb58f1046c285dacbce4d28cdf65d") --Dlc Windows Language Depot French Fallout 4 - Nuka-World
addappid(393897, 1, "66d2d640107c97b2f9e6938c760a2e6ca4e1d9b6da94dc0d145fec9bcee4d63e") --Dlc Windows Language Depot German Fallout 4 - Nuka-World
addappid(393898, 1, "300e5b750a37042421928a85da7379f0699b335c7faa850e0565fc54f66abcd1") --Dlc Windows Language Depot Spanish Fallout 4 - Nuka-World
addappid(393899, 1, "7202ca82570a85a8a4b0b8bb2e71e2163dfbf4cf27ade944fa48b24a98b27b4e") --Dlc Windows Language Depot Russian Fallout 4 - Nuka-World
addappid(404094, 1, "b03df53e25101784f9c0435d32a074f8bcb5722bb817f0e8500e68a017a826a1") --Dlc Windows Language Depot Brazilian Fallout 4 - Nuka-World
addappid(404095, 1, "8c9c875159b7d5d1b83d8eb006c74c7d2b55a25eb16e698b1d4f3d023e260e64") --Dlc Windows Language Depot Tchinese Fallout 4 - Nuka-World
addappid(404096, 1, "2b21b8ea82ac24e61036ef98a7d4ab8bf2a14f5d48c80165d4feccf3134815ca") --Dlc Windows Language Depot Japanese Fallout 4 - Nuka-World
addappid(404097, 1, "51b10b95caf52ff20c3229ae88bc1864f4d6e551068210fb925f0c39240c7e9e") --Dlc Windows Language Depot Polish Fallout 4 - Nuka-World
addappid(540810, 1, "5dd2a475e216eeb88d5cd53029eca47658f369ba24850e133e54b0f0e4a716bb") --Dlcname Fallout 4 - High Resolution Texture Pack
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
addappid(404090) --Dlcname Fallout 4 Season Pass
addtoken(404090, "9125628652905021850")
addappid(598110) --Dlcname Fallout 4 - Creations
addappid(3868650) --Dlcname Fallout 4 - Creations Bundle

-- MANIFESTS / UPDATES
setManifestid(377161, "5983086794954940044", 5585568768)
setManifestid(377162, "4737695048810094469", 20291776)
setManifestid(377163, "5944191827186292545", 19775430336)
setManifestid(377164, "8492427313392140315", 3400681728)
setManifestid(377165, "2033965788399743191", 3314916096)
setManifestid(377166, "5627643066330450040", 3456786992)
setManifestid(377167, "7494413550139810042", 3464705472)
setManifestid(377168, "3728836035123485280", 3420705360)
setManifestid(393880, "4656512446653497676", 3340937696)
setManifestid(393881, "9220466047319762009", 3340855520)
setManifestid(393882, "8191305962459798887", 3340826128)
setManifestid(393883, "8665224215527782698", 3400681776)
setManifestid(393884, "7858461782713595876", 6296841904)
setManifestid(404091, "700800914500035486", 254335072)
setManifestid(435870, "1213339795579796878", 383488992)
setManifestid(435871, "2409405813420002782", 114864384)
setManifestid(435872, "941934804697401215", 118602400)
setManifestid(435873, "3980020322585784443", 146560704)
setManifestid(435874, "3956363256584016071", 112268320)
setManifestid(435875, "8606234772023531308", 154513296)
setManifestid(435876, "7058589417191373328", 114868896)
setManifestid(435877, "8576126724542625620", 114868896)
setManifestid(435878, "2391692612495043030", 114868896)
setManifestid(435879, "5768554783695971854", 248463488)
setManifestid(435880, "3925034910761260929", 56733456)
setManifestid(404092, "6806984433357643395", 497625184)
setManifestid(404093, "1398706778481280442", 521271360)
setManifestid(435881, "1207717296920736193", 1973772368)
setManifestid(435882, "8482181819175811242", 497625184)
setManifestid(435883, "8148702710057205377", 493824816)
setManifestid(435884, "1583726361179064237", 483610656)
setManifestid(435885, "545294059663977441", 494216496)
setManifestid(435886, "6337694505107499720", 494141872)
setManifestid(435887, "1696734609684135531", 497625184)
setManifestid(435888, "2814340383581262374", 497625184)
setManifestid(435889, "3739447432423498108", 497625184)
setManifestid(480630, "5527412439359349504", 199507968)
setManifestid(393885, "5000262035721758737", 45902528)
setManifestid(393886, "4075502974578231964", 43397504)
setManifestid(393887, "4458604458983717666", 46189056)
setManifestid(393888, "4182964460983125860", 43386304)
setManifestid(393889, "7553859846726526417", 45880544)
setManifestid(393890, "1765554658221186452", 45902528)
setManifestid(393891, "631542034352937768", 45902528)
setManifestid(393892, "1388883862084490494", 45902528)
setManifestid(393893, "442593679549850747", 45902528)
setManifestid(393894, "284738489375199037", 45361840)
setManifestid(480631, "6588493486198824788", 302722608)
setManifestid(377169, "2112185424871906435", 311513456)
setManifestid(393895, "7677765994120765493", 313107664)
setManifestid(393896, "4271967849859961419", 293735184)
setManifestid(393897, "1357704281835463005", 302803472)
setManifestid(393898, "8573679706590820412", 320506560)
setManifestid(393899, "1428451409051936353", 313107664)
setManifestid(404094, "2888111047071072771", 313107664)
setManifestid(404095, "3169890264626778200", 950985936)
setManifestid(404096, "2951208112779014496", 965994960)
setManifestid(404097, "3040241873036299160", 313107664)
setManifestid(490650, "4873048792354485093", 3025922416)
setManifestid(540810, "1558929737289295473", 59109935776)
setManifestid(228984, "2547553897526095397", 13436144)
setManifestid(228990, "1829726630299308803", 100658080)
