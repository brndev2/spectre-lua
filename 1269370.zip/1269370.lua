addappid(1269370, 1, "fdb2ad0e48d5eec8e1c55ef84b581d825bba7506157b58558feddaaec9b1992d") --Mainappid 171
addappid(1269371, 1, "7e1df33a1b894f1b0fc4c79a77610962f3609cf5368826bc77c7ec80241fdf09") --Main Windows Depot 171
setManifestid(1269371, "1382098005489509585", 6964828624)
--Share Depots
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228984, "2547553897526095397", 13436144)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228985, "3966345552745568756", 13244128)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228988, "6645201662696499616", 22411856)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228989, "5753583882400741046", 25108528)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)