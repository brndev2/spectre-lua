-- Lua provided by RyzenAPI
-- Game: Ghost of Tsushima DIRECTOR&#39;S CUT

-- MAIN APP DEPOTS / PACKAGES
addappid(2215430) --Mainappid Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(2215431, 1, "dfc6d3958470277318949e0773165b9ce5d26f6ae73e2d37b9edfe4b934067a1") --Main Windows Depot Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(2215432, 1, "b218c016d1b02dd7d4722fe5d6bcf3d44d8a8c978f493678df8a98d855e74c8a") --Main Windows Depot Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(2215434, 1, "d712c2f977a832063ecdee3943236ccfdfc386c19d05a30c85a880273ab6f110") --Main Windows Depot Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(2215435, 1, "3b81d2d844c42ba84e7f1148c247462c18b8c866280a04ec7911186bbcc980cb") --Main Windows Language Depot French Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(2215436, 1, "70f30c99113cd922e3922176112072fb0342fa8ea9d70ab21b2b9c9490095bda") --Main Windows Language Depot German Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(2215437, 1, "e57984af0d5ec477c23316b244de1e09be8a1cc1b7818765e71d229d5b6d025a") --Main Windows Language Depot Italian Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(2215438, 1, "7700f2391ea9b7bdeae2d69c20788091cad2d095c83a4c78f0d2ba27673b75d3") --Main Windows Depot Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(2374401, 1, "178cd22d92120cd366e68ec088399abb594be5eec78799a05eebe3af9b0cc078") --Main Windows Language Depot Polish Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(2374402, 1, "0618ff72abfe8aed89c4220aa8b4e88ba392647dda99471696237c05b8c0c163") --Main Windows Language Depot Brazilian Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(2374403, 1, "e54d4cd0930e0f16e1e19d6cc7b45cefcc4d7178d2bbbbf0fc9640dd00d884bd") --Main Windows Language Depot Portuguese Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(2374404, 1, "1b65fb40764978104667193422e1797e9a41484825b0a684a881e6a077322144") --Main Windows Language Depot Russian Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(2374405, 1, "20e0bd9426f12532d58d6806e810957c22dadd475463bafb50fab9fc147a35d5") --Main Windows Language Depot Latam Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(2374406, 1, "0c450f698f7c08adbe60ca98ec5298f7adbd213a8b7e0e016e5acabb22d12d84") --Main Windows Language Depot Spanish Ghost of Tsushima DIRECTOR&#39;S CUT
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Share Windows Depot Steamworks Common Redistributables
addappid(2686280) --Dlcname Ghost of Tsushima DIRECTOR'S CUT - Pre-purchase Entitlements
addappid(3929730) --Dlcname Ghost of Tsushima: Legends (Unlock)

-- MANIFESTS / UPDATES
setManifestid(2215431, "7524577377638837640", 48244252192)
setManifestid(2215432, "6112308963848125088", 472915296)
setManifestid(2215434, "880597362622556889", 1432913888)
setManifestid(2215435, "1741259271972069973", 1522365792)
setManifestid(2215436, "2342834755630514714", 1502878608)
setManifestid(2215437, "6645149111657224998", 1511899744)
setManifestid(2215438, "6525424500655659607", 1466635920)
setManifestid(2374401, "204690583444440935", 1466155904)
setManifestid(2374402, "5900367963458568890", 1461622400)
setManifestid(2374403, "4982117972751931186", 1494541424)
setManifestid(2374404, "7968686865299155539", 1577054752)
setManifestid(2374405, "3652298622322133746", 1440685312)
setManifestid(2374406, "8170256765332020951", 1475384816)
setManifestid(228989, "5753583882400741046", 25108528)
