-- [Core Application]
addappid(4356430) -- NBA 2K27

-- [Content Depots]
addappid(4356431, 0, "a1ccdda87579dfa269b9015cc7ba18b7eb8339848b5eb408bfea8bdfb31eb8a4")
setManifestid(4356431, "2271080181003010218")
addappid(4687050, 0, "c96a0954f3836680afb31e3b837546bb92606ccaebcc3e1bf8cd3761b8221c25")
setManifestid(4687050, "4767089068737929486")

-- ============================================================
-- Total Depots: 2
-- Shared Depots: 0
-- DLCs:         0
-- ============================================================
