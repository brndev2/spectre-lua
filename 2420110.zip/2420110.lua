addappid(2420110, 1, "7a4dd21a77ea873254d9d5144435e2847a75590769837fce2fc0ed34ff84a1cc") --Mainappid Horizon Forbidden West™ Complete Edition
addappid(2420111, 1, "5efc60abd1c102f2ede64fbddb1fcb58fc7b156ef8410eba8ce90a458a09082a") --Main Windows Depot Horizon Forbidden West™ Complete Edition
setManifestid(2420111, "2239037909320851046", 101670743712)
addappid(2420112, 1, "45ee1a9a56ddd7b41370387bc6a3c6ece37bab529fa3313c7543c1b5ec044b93") --Main Windows Depot Horizon Forbidden West™ Complete Edition
setManifestid(2420112, "7917507670516987083", 108205664)
addappid(2420114, 1, "d7abeb87bdc4c80e6c40a78b0681d32db2cbd17261c2ad793c2b8acee674a669") --Main Windows Depot Horizon Forbidden West™ Complete Edition
setManifestid(2420114, "6680338608508653005", 2311937776)
addappid(2420115, 1, "5908a0f1461073db73b0d36ce13aff474c6243e9aeb57bbf13490f31fcc1a082") --Main Windows Language Depot French Horizon Forbidden West™ Complete Edition
setManifestid(2420115, "3856210151677793842", 2146027808)
addappid(2420116, 1, "f525051ae30cdf8d4525cd997f307713341a438173122b522a281752db8728a4") --Main Windows Language Depot Italian Horizon Forbidden West™ Complete Edition
setManifestid(2420116, "4697055530980282507", 2265353248)
addappid(2420117, 1, "18c0f17fc983e33fe47b8d40449f3d561d3eed66916e0fcb19ee469f5618d32e") --Main Windows Language Depot German Horizon Forbidden West™ Complete Edition
setManifestid(2420117, "5295276332778237670", 2362482816)
addappid(2420118, 1, "98e66b59c1c5e5ec56e36dbe5d4bb42af86d6c3e3a4f0d7874065667f1a2600d") --Main Windows Language Depot Spanish Horizon Forbidden West™ Complete Edition
setManifestid(2420118, "8673415990553381851", 2160907216)
addappid(2420119, 1, "661789bfc4fbe123e06843e92004d16fe7b37f293454616f542bb164b565fb5a") --Main Windows Language Depot Polish Horizon Forbidden West™ Complete Edition
setManifestid(2420119, "5380212226787194873", 2379090224)
addappid(2452461, 1, "e1a93cdacf0ff6fdc39ea109f0eb689e44d173896b912571537c25e26c959e69") --Main Windows Language Depot Portuguese Horizon Forbidden West™ Complete Edition
setManifestid(2452461, "5708538598987781196", 2195018992)
addappid(2452462, 1, "2febd6f0d43778130ff358538c1bf064e446804f1d403865e464d89dd3499865") --Main Windows Language Depot Russian Horizon Forbidden West™ Complete Edition
setManifestid(2452462, "8564962424144066599", 2409555280)
addappid(2452463, 1, "4ddd210beeda422859f5ad26eabcb8798923f613e593bd1182df53f7ddbbb447") --Main Windows Language Depot Arabic Horizon Forbidden West™ Complete Edition
setManifestid(2452463, "8307697578226900422", 2429239872)
addappid(2452464, 1, "7cdc9b96c0640b7c68fc508e90b535538e06b82596e4c6ece54b2e126a4629ab") --Main Windows Language Depot Japanese Horizon Forbidden West™ Complete Edition
setManifestid(2452464, "2151180198015552420", 2376830368)
addappid(2452465, 1, "f5a7d177f62ba6108d394056d583a52653d086d6c87eb844331fb714ac57c9eb") --Main Windows Language Depot Latam Horizon Forbidden West™ Complete Edition
setManifestid(2452465, "343860007184336722", 2260587280)
addappid(2452466, 1, "202f3496feff614800225f52837d623bcefacd68f7049451f3ec6b2ce62d1e8b") --Main Windows Language Depot Brazilian Horizon Forbidden West™ Complete Edition
setManifestid(2452466, "3510327789903158350", 2279543472)
--Share Depots
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228989, "5753583882400741046", 25108528)
addappid(2749700) --Dlcname Horizon Forbidden West™ Complete Edition - Pre-Purchase Entitlements