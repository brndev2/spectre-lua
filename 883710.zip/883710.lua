-- Lua provided by RyzenAPI
-- Game: Resident Evil 2

-- MAIN APP DEPOTS / PACKAGES
addappid(883710, 1, "539c9713dc0ec8741ec053727c1e58b18b98515d77c404c05f9a9768e625aec1") --Mainappid Resident Evil 2
addappid(883711, 1, "638f06d7569ecead867a27e5934284446cbf9a8740638265114ad27fb4ce2f27") --Main Windows Depot Resident Evil 2
addappid(883712, 1, "64aebcf6ac355fbc07d5edeb037ef5d1ecdd3415cc520f397e3674edd078fd84") --Main Windows Depot Resident Evil 2
addappid(883713, 1, "f0afbce3fe63581d5b1179fe571e137761ed6ca98455ee6606650f4b09f5249e") --Main Windows Depot Resident Evil 2
addappid(883714, 1, "27631926b9162a5355df9eb09fdd90efe7631dcb86a2a34edbbd04fdb3ddbe02") --Main Windows Depot Resident Evil 2
addappid(883715, 1, "a8afa9147111fd2590f12a2efafb74a91f4c9ac15eb56cdaaee4eb70b8b513ee") --Main Windows Depot Resident Evil 2
addappid(883716, 1, "cdbca1dcd27611eab5a12f53db738d8d0012572146b930e71578f21d7662317c") --Main Windows Depot Resident Evil 2
addappid(883717, 1, "66abdff706240ae3c2faa39ccb3d9cf90c2ba61cf80d0b94b5e40fc467e8dab5") --Main Windows Depot Resident Evil 2
addappid(883718, 1, "bed9e589ec8c4a42f4f4c4165ea55ef524cc1a746466f0cd0dcec717d7422fd0") --Main Windows Depot Resident Evil 2
addappid(883719, 1, "efe4f1a93047a0d60991536337e376ccc14e11b701a2a7b9140b0080c53bf5ea") --Main Windows Depot Resident Evil 2
addappid(920572, 1, "dbd486a37d92e45a6cb1125e71b80bd31ce74e3732a72384b26103d71f27af5c") --Main Windows Depot Resident Evil 2
addappid(920573, 1, "a440dc284213e39f98528e058fa3457f1c6a9bbfbc97f6794a6b81f46056df2b") --Main Windows Depot Resident Evil 2
addappid(1335174, 1, "59f5e2bd325f2833f26c807948ee273587d29eab0e57e49e290504d88b4fc5ae") --Main Windows Language Depot Japanese Resident Evil 2
addappid(1335175, 1, "937b7a653794b8f87e282c794197b1ca4044b64baedce72ddaf0a326601d374f") --Main Windows Language Depot Japanese Resident Evil 2
addappid(1335176, 1, "be5a38031d635da2ea38a7baffa11d18797931045c1ff6d284a3d3d72818174b") --Main Windows Language Depot Japanese Resident Evil 2
addappid(920560, 1, "ed972f698b50ed84c8edc351a84adc57ef81a9d75dfdc05f87297e2caa4741e3") --Dlcname Resident Evil 2 - Leon Costume: Arklay Sheriff
addappid(920561, 1, "bb62b32357a66bdfb10eb2a374912ffa9ba58924252603e1935226520aea8513") --Dlcname Resident Evil 2 - Leon Costume: Noir
addappid(920562, 1, "71020da471eab8cf287e8b1364dc41774641785316eef961b1bf872b2e81426b") --Dlcname Resident Evil 2 - Claire Costume: Military
addappid(920563, 1, "e970b08de60e4726cf9020d6eba9cc48c1dc79053e7000033ddb28c328c7ee34") --Dlcname Resident Evil 2 - Claire Costume: Noir
addappid(920564, 1, "194df6fccffb69f0b91badf8550570c554f9dd2ba7a8ce025c23b2e1b707de51") --Dlcname Resident Evil 2 - Claire Costume: Elza Walker
addappid(920565, 1, "cc4cc3692f32ee8a0e912af30b2a6c7d63ca6625dfe904bc9c8a7fe7e27c3f45") --Dlcname Resident Evil 2 - Leon Costume: 98'
addappid(920566, 1, "747b360f6029581b9e552dbadd556684c85b21f80c6d812a6ea68f48b8e38630") --Dlcname Resident Evil 2 - Claire Costume: 98'
addappid(920567, 1, "1cb02d129e55942d541b1f1c88365d043c8a0cce730a25ec3c56a15c77523def") --Dlcname Resident Evil 2 - Original Ver. Soundtrack Swap
addappid(920568, 1, "dd350bfb23bfd3c931f2589bab2b0ce0eff6704491a777ff4db51439cb2bf94c") --Dlcname Resident Evil 2 - Deluxe Weapon: Samurai Edge - Albert Model
addtoken(920569, "9210640672866114780")
addappid(920569, 1, "d5951968c5c68af4a7e4cca71625a71dfb289fc98e170a6e25e87221faac71f5") --Dlcname Resident Evil 2 - Deluxe Weapon: Samurai Edge - Jill Model
addtoken(920570, "12658968023885460684")
addappid(920570, 1, "7b918b3037406996a31fddfade6f149ee7a41e6dff77548200886097deb98ec6") --Dlcname Resident Evil 2 - Deluxe Weapon: Samurai Edge - Chris Model
addappid(920571, 1, "04ba2f12b585affc9ed2cc03b5b04f136e6159ea7430892ae71c5a541c7ae427") --Dlcname Resident Evil 2 - All In-game Rewards Unlocked
addappid(1335170) --Dlcname Resident Evil 2 Original Soundtrack
addappid(1335171, 1, "4d297206313f28ad5d949cce4c784580858a00eea8ce6b2c3cbcfc8aaec9bfa2") --Dlc Windows Depot Resident Evil 2 Original Soundtrack
addappid(1335172, 1, "b266d8cb0b35c44a8aa70933ea54633700a18ac38122a6ff032d58133f92297e") --Dlc Windows Depot Resident Evil 2 Original Soundtrack
addappid(1335173, 1, "e00c6c0ae3252e9230c32e14d531bc7c6ab85f87107e4d6649f99a7ffa035b6f") --Dlc Windows Depot Resident Evil 2 Original Soundtrack
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables

-- MANIFESTS / UPDATES
setManifestid(883711, "1276883776777242280", 24053480912)
setManifestid(883712, "4308061999662339354", 24214712320)
setManifestid(883713, "5793354868189524285", 32660912)
setManifestid(883714, "5577253524310892660", 199888080)
setManifestid(883715, "1048038669598412361", 23268939952)
setManifestid(883716, "6893789202571151145", 23309785680)
setManifestid(883717, "594447121131702131", 269418208)
setManifestid(883718, "5949125275142682173", 530162224)
setManifestid(883719, "2758490342177349494", 0)
setManifestid(920572, "4813678597596508063", 243628640)
setManifestid(920573, "419112001528634823", 243428960)
setManifestid(1335174, "1543985210876453207", 343566160)
setManifestid(1335175, "3034441359739052082", 874382416)
setManifestid(1335176, "4504645473131763140", 443206624)
setManifestid(920560, "3707796803102380515", 150923200)
setManifestid(920561, "7777910790301298561", 150655920)
setManifestid(920562, "6204099557140371425", 136749888)
setManifestid(920563, "6596791651819430825", 96226336)
setManifestid(920564, "4567165216698197061", 112423936)
setManifestid(920565, "510135806956799705", 37387632)
setManifestid(920566, "7570154016218765728", 38007264)
setManifestid(920567, "3579676083509558298", 80126720)
setManifestid(920568, "3078911744541340384", 57289344)
setManifestid(920569, "3611674127107630311", 59494112)
setManifestid(920570, "7297738854267208684", 59597792)
setManifestid(920571, "7444394391996341768", 7952)
setManifestid(1335171, "7244248912816111109", 343378544)
setManifestid(1335172, "2903400760900422105", 874191584)
setManifestid(1335173, "227831042820592391", 443018576)
setManifestid(228987, "4302102680580581867", 22936736)
setManifestid(228990, "1829726630299308803", 100658080)
