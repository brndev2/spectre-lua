-- Lua provided by RyzenAPI
-- Game: Mafia: Definitive Edition

-- MAIN APP DEPOTS / PACKAGES
addappid(1030840, 1, "79080e53a9757e2f89c87a78ca83397a6cc0069c5ac00e8c66b463ce7ab276ef") --Mainappid Mafia: Definitive Edition
addappid(1030841, 1, "d6e79f53321a7947e8963e27e1baefb862ce738eb51a2fa8eeaa90c476917f64") --Main Windows Depot Mafia: Definitive Edition
addtoken(1316300, "16475343798686789276")
addappid(1316300, 1, "724c017202bf35f19f8cdbbec2e6a859a2d88b805b1abe089d4d8a329b318471") --Dlcname Chicago Pack
addappid(1421480) --Dlcname Mafia: Definitive Edition - Official Score
addappid(1421481, 1, "c703f0ad825f17cd127af65bdc171438ea1bf97f81c01c6caa9a9d62aa27aa68") --Dlc Windows Depot Mafia: Definitive Edition - Official Score
addappid(1421482, 1, "392719da2d30688cb6ab03883c3d1629e4dc80696ee749390170737060097ec2") --Dlc Windows Depot Mafia: Definitive Edition - Official Score
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") --Share Windows Depot Steamworks Common Redistributables
addappid(1523211, 1, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b") --Share Windows Depot AppID 1523210

-- MANIFESTS / UPDATES
setManifestid(1030841, "2886022585972111903", 37139405344)
setManifestid(1316300, "1697495207204236421", 1632)
setManifestid(1421481, "6303477431289288047", 198715392)
setManifestid(1421482, "5183706551542093734", 787487632)
setManifestid(228988, "6645201662696499616", 22411856)
setManifestid(1523211, "5488617169383930545", 128)
