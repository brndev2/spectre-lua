-- Lua provided by RyzenAPI
-- Game: Marvel’s Spider-Man Remastered

-- MAIN APP DEPOTS / PACKAGES
addappid(1817070, 1, "5d889f9e52a4957f1c3853310182be31551ec3aef31dffa31c3155d4535937ef") --Mainappid Marvel’s Spider-Man Remastered
addappid(1817071, 1, "490a357029d1621deff9708e5d42f19324ccc758124ae1b455e091551df2a041") --Main Windows Depot Marvel’s Spider-Man Remastered
addappid(1817072, 1, "ae2589c0e9de7a18dea92ceac08a6537cf7b83c1983e9f4738a188a49fd137f9") --Main Windows Depot Marvel’s Spider-Man Remastered
addappid(1817074, 1, "d1d379b15dba708a435fa177bacfc7f625c53c84b45b299ded3cbeeca084e330") --Main Windows Depot Marvel’s Spider-Man Remastered
addappid(1817075, 1, "ecb149a90bf5eda310dd5f18e7715c255b022db3e327037cc6daa4f69ff22107") --Main Windows Language Depot French Marvel’s Spider-Man Remastered
addappid(1817076, 1, "6cb4d05622fdd2cd0d10703a36cf47140a2d952a49e31325a3b65af53db59974") --Main Windows Language Depot German Marvel’s Spider-Man Remastered
addappid(1817077, 1, "3e7903be905c0a12045d1f7d303e596ca9889e64b0b2f4a5e52680e7839b20fb") --Main Windows Language Depot Italian Marvel’s Spider-Man Remastered
addappid(1817078, 1, "9815d29285202efd418b703002a67cf17ccde07230fe3f2b171e1581d17ba0e4") --Main Windows Language Depot Japanese Marvel’s Spider-Man Remastered
addappid(1817079, 1, "e357c3433e694ca3c616af966efc889f3d6af51c4d45e34fbf3d6537715c9bf0") --Main Windows Language Depot Polish Marvel’s Spider-Man Remastered
addappid(1829890, 1, "fc8ce2606acf5525e88dffc6cdc9cd4cf50e092efa04536528ee66fda012fe79") --Main Windows Language Depot Portuguese Marvel’s Spider-Man Remastered
addappid(1829891, 1, "69db276eece234ce4caf8b55262d17c74686450104a1d1db09cfdc425555b707") --Main Windows Language Depot Brazilian Marvel’s Spider-Man Remastered
addappid(1829892, 1, "cd4dd166b577600a9fe435ad640a58caa41fb8311111ab403c24a7b1d5a29ed9") --Main Windows Language Depot Russian Marvel’s Spider-Man Remastered
addappid(1829893, 1, "48c0acb19e2fc2d02db4b9dcf88fabf25c8eb7eb1e218b7f26c54a53073bb934") --Main Windows Language Depot Spanish Marvel’s Spider-Man Remastered
addappid(1829894, 1, "1406f2b316ca60231c614560afc407a0b3eca5c0cce4e46f5493e73f269808ef") --Main Windows Language Depot Latam Marvel’s Spider-Man Remastered
addappid(1829895, 1, "4773012855296205ad41eeb15231c6d5db4ee4264feb5b217e8b09b752c4526c") --Main Windows Language Depot Arabic Marvel’s Spider-Man Remastered
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") --Share Windows Depot Steamworks Common Redistributables
addappid(2083110) --Dlcname Marvel's Spider-Man Remastered - Pre-purchase Entitlements

-- MANIFESTS / UPDATES
setManifestid(1817071, "3826860471854644257", 54482297232)
setManifestid(1817072, "2734256798601145338", 121525632)
setManifestid(1817074, "2767115330843299188", 1202218112)
setManifestid(1817075, "3039496220919935469", 1258559408)
setManifestid(1817076, "7023492310614800670", 1288219968)
setManifestid(1817077, "1086775484848552274", 1272963408)
setManifestid(1817078, "5917343255803174273", 1231994480)
setManifestid(1817079, "2023143758263501793", 1257754128)
setManifestid(1829890, "3390700499140811325", 1187232944)
setManifestid(1829891, "245862505056949822", 1219770288)
setManifestid(1829892, "1540729933509716096", 1245716992)
setManifestid(1829893, "1590101423645348968", 1283346176)
setManifestid(1829894, "3419249952092460430", 1300431248)
setManifestid(1829895, "4268839994794210418", 1231266992)
setManifestid(228988, "6645201662696499616", 22411856)
