-- Lua provided by RyzenAPI
-- Game: Farming Simulator 22

-- MAIN APP DEPOTS / PACKAGES
addappid(1248130, 1, "5fe3ae2eb2b6bd4c9a64dadc45353a200b1efe719c08bd65b39b39f3ce107c5d") --Mainappid Farming Simulator 22
addappid(1248131, 1, "f2d9d950b6d27abfd34991fdd808f2f540c0536f8ba9b5e72f2f98d5214dc37a") --Main Windows Depot Farming Simulator 22
addappid(1248132, 1, "7cbf9174875e809f36c633a7e9e576ab988749fe464b4a7d421fba29d4172f1c") --Main Macos Depot Farming Simulator 22
addappid(1248133, 1, "d0394544ec7a54be3278752d7e34b90c716c82cd16cece8bf32a4dc65dfcde25") --Main Windows Language Depot English Farming Simulator 22
addappid(1248134, 1, "d931025e2010a18ca6e15e1803cc4d79557f2b547e7c1c0d656963269def5ea2") --Main Windows Language Depot German Farming Simulator 22
addappid(1248135, 1, "15c6f45fae84c4ac52802700d64010e141aaf0813ed33749aee0f066680faae7") --Main Windows Language Depot French Farming Simulator 22
addappid(1248136, 1, "0ea757457af0a2053ea6358b6e46bfc17ee7d66953889a029391bad9f4571234") --Main Windows Language Depot Italian Farming Simulator 22
addappid(1248137, 1, "44182abe99611bc771be04052b4cfab7d2e7aa584f0d1566c6f0e4ee9708552a") --Main Windows Language Depot Koreana Farming Simulator 22
addappid(1248138, 1, "c2365feee84d8d2feac4c9cc6937f3a3544a8dd6e9d06313e159f129e463ac91") --Main Windows Language Depot Spanish Farming Simulator 22
addappid(1673990, 1, "e0b3f963a6006b1e0767bde723c8256b6b2daee63b97a0e173d562a060564362") --Dlcname Farming Simulator 22: CLAAS XERION SADDLE TRAC Pack
addappid(1767680, 1, "a95c1737993bdfcdd32952d618ca067a79ffaae389e3c3eeb4ab2a2ccc492a15") --Dlcname Farming Simulator 22: Mack Trucks - Black Anthem
addappid(1767690, 1, "8c8a327e3c58bfbad26017de0d48456e6424a222ac5dee9bf87d9ed9b6bb2ea3") --Dlcname Farming Simulator 22: Fendt 900 Black Beauty
addappid(1767691, 1, "1c6b5fec05bf2f55883d9022248352a0b68d1e8413de6c7c9c2e20b83cc2cb53") --Dlcname Farming Simulator 22: Zetor 25 K
addappid(1879480, 1, "db90f980c61f0f7646397841e0d5c8ee03b289bf31b27bb3e2fab13848117b3c") --Dlcname Farming Simulator 22: ANTONIO CARRARO Pack
addappid(1967740, 1, "e581078ebe1b5b3f8ed0c5718c2f1d2aba8c99183fc4df1b58adb4fd55d2eabb") --Dlcname Farming Simulator 22: AGI Pack
addappid(1988850, 1, "4679646434d017f459bac1728dcb02c9e643d8cc706a455e6b40f2ffdebdfe1f") --Dlcname Farming Simulator 22: Kubota Pack
addappid(1992250, 1, "68cb066ff9ad1ad4ec0955bce414c59e38de0ada94dc932cf15010a9a432fb85") --Dlcname Farming Simulator 22: Vermeer Pack
addappid(2024410, 1, "a01374d5a7217703abb0fe5e7dbd8e341692eeb876733258bacd186f74482c0c") --Dlcname Farming Simulator 22: Platinum Expansion
addappid(2052720, 1, "5cc15a4f2de8fd085bc06864dbc78ddea95dbff5637d740781eb400849e2a8ad") --Dlcname Farming Simulator 22: Pumps n' Hoses Pack
addappid(2060460, 1, "fe4d6258819441bf60d4bc151b8573665ba3900eb7bf77291a98a32c3cf77789") --Dlcname Farming Simulator 22: ERO Grapeliner Series 7000
addappid(2118730, 1, "7cfaeb65936dae11b9d0c30600c8ee114738e817161a451d30fa289abdb387dd") --Dlcname Farming Simulator 22: Volvo LM 845
addappid(2118740, 1, "3c24038f11e4dbf9292dfeb38718dc06c305d31e46965fa75c6b4fab941da2d8") --Dlcname Farming Simulator 22: Volvo T 425 Krabat
addappid(2171790, 1, "754ae3e4970f0b42e6db7151fba1282655e08e7110e165b0ac2639e1d5ebe465") --Dlcname Farming Simulator 22: Porsche Diesel Junior 108
addappid(2243160, 1, "e53454d942b2654e9c35f2ecf1855a22d8ddf853f6a56a2b1e7da6797c1f5616") --Dlcname Farming Simulator 22: Göweil Pack
addappid(2243170, 1, "23545bd6876c76691366242bb1c97531b35d7c276de4d89a320fefc5f0dc7d20") --Dlcname Farming Simulator 22: Hay & Forage Pack
addappid(2243180, 1, "3135ba34f0418b65513bcd657092962292ccff1a7cf91f93deddcbc077a874c6") --Dlcname Farming Simulator 22: HORSCH AgroVation Pack
addappid(2243190, 1, "09bce9840039597da1b5d8b4f9aba105b82d741a5f16c85106886cfe3d184af5") --Dlcname Farming Simulator 22: OXBO Pack
addappid(2243200, 1, "3c085e2eecb88d51bac29d7ed7688ab23bafc00cdc67b229e3931ffddc5dd04d") --Dlcname Farming Simulator 22: Premium Expansion
addappid(2620980, 1, "88fdb11e5a26f96db726f95341793de96085b44fe9a2b77046dfe14271536fd2") --Dlcname Farming Simulator 22: Case IH Farmall Anniversary Pack
addappid(2834020, 1, "225b5a720c571e5a1e60841f7ca8b9e400f9d48f2ad263c92b0a159bf9eedee6") --Dlcname Farming Simulator 22: Farm Production Pack
addappid(1731910) --Dlcname Farming Simulator 22: Year 1 Season Pass
addappid(2178810) --Dlcname Farming Simulator 22: Year 2 Season Pass

-- MANIFESTS / UPDATES
setManifestid(1248131, "828510169982133884", 16188659856)
setManifestid(1248132, "3500327048525161053", 15612945200)
setManifestid(1248133, "4618561879047779171", 0)
setManifestid(1248134, "3422070113579301620", 0)
setManifestid(1248135, "4475626736983645437", 0)
setManifestid(1248136, "6834781470726443073", 0)
setManifestid(1248137, "1922945346341920237", 0)
setManifestid(1248138, "9092994224644967653", 0)
setManifestid(1673990, "1062251328472408350", 89090080)
setManifestid(1767680, "3234084343676613818", 13408)
setManifestid(1767690, "8570258775106909972", 13408)
setManifestid(1767691, "5870147096462724396", 13360)
setManifestid(1879480, "5011842175521273659", 181124320)
setManifestid(1967740, "9177020325140251542", 102800416)
setManifestid(1988850, "6832232227991319596", 253703088)
setManifestid(1992250, "3202945344734599974", 80425712)
setManifestid(2024410, "5703765128383730924", 3382920240)
setManifestid(2052720, "2308112217163877561", 688632448)
setManifestid(2060460, "6400597163278892789", 55454880)
setManifestid(2118730, "6735190368104136657", 35088)
setManifestid(2118740, "3092276717910398577", 35056)
setManifestid(2171790, "2537414244908965707", 35104)
setManifestid(2243160, "2115387195750703084", 296147104)
setManifestid(2243170, "7610373529691780140", 326569808)
setManifestid(2243180, "5715031455963173775", 989587568)
setManifestid(2243190, "8191973273789748966", 262965856)
setManifestid(2243200, "7525337098517332911", 2851467328)
setManifestid(2620980, "3199981134047764534", 35088)
setManifestid(2834020, "1967441239416157837", 230782176)
