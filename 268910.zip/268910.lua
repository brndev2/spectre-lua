-- Lua provided by RyzenAPI
-- Game: Cuphead

-- MAIN APP DEPOTS / PACKAGES
addappid(268910, 1, "96dd9e25c9ccf769568c2c6d984e2cdad455b446bd1c1985e85d195806de42c0") --Mainappid Cuphead
addappid(268911, 1, "5f5e2d0105e9fcfbd0c7151658efd92af0181865fe434192f8e2c5d24d4940da") --Main Windows Depot Cuphead
addappid(268912, 1, "6378a6f3808fd925e8fdc2cd115d7b60f1908a6dff6b5f6c1fb0af7f392db1e4") --Main Macos Depot Cuphead
addappid(704710) --Dlcname Cuphead - Official Soundtrack
addappid(704711, 1, "355f7a6485745876ae337f59efb63a2a7c2012d8cfcbaf99fe6e93b511184b03") --Dlc Windows Depot Cuphead - Official Soundtrack
addappid(704712, 1, "1d311725ca119b72edfa849cbbe123b72e39cdaef19dc8a22f15529d8ef2a556") --Dlc Windows Depot Cuphead - Official Soundtrack
addappid(1117850, 1, "c40d10dcd40756563a4956777e0bb4333e48d34c00e2836edd3d5fdbc0eba095") --Dlcname Cuphead - The Delicious Last Course
addappid(1117851, 1, "1d08dafb023ed4a43d3def619d54ace53b3b4bced035e744da83b4449f26cac7") --Dlc Macos Depot Cuphead - The Delicious Last Course
addappid(2072990) --Dlcname Cuphead DLC - Official Soundtrack
addappid(2072991, 1, "2b53c9cd8ecf62cc469ee5f1f0cecb6e1217f9c766e5c58eb95084107868da66") --Dlc Windows Depot Cuphead DLC - Official Soundtrack
addappid(2072992, 1, "fff30d5cdd3c7b9f7436ac0f2c962ec5ab80282ddb8cf0129eaa6723909c9724") --Dlc Windows Depot Cuphead DLC - Official Soundtrack
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables

-- MANIFESTS / UPDATES
setManifestid(268911, "2961019062399342472", 3362563152)
setManifestid(268912, "8936126933278923535", 3365201744)
setManifestid(704711, "4630179950063277534", 425933200)
setManifestid(704712, "7905790265200937644", 1105313232)
setManifestid(1117850, "7764187989484304781", 1569136976)
setManifestid(1117851, "4830840309801799910", 1569116368)
setManifestid(2072991, "7794271606339901763", 163528944)
setManifestid(2072992, "6626318741336770131", 428428704)
setManifestid(228990, "1829726630299308803", 100658080)
