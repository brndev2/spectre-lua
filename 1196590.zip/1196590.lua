-- Lua provided by RyzenAPI
-- Game: Resident Evil Village

-- MAIN APP DEPOTS / PACKAGES
addappid(1196590, 1, "5540e7492fe9a6b06aa86fcac6251b512b4bbb781df477b6b0a3db1ff677dae7") --Mainappid Resident Evil Village
addappid(1196591, 1, "7ccf761ec4f6be4f36416cd1304044deb8b419204f823cae95c9d9f64f94297c") --Main Windows Depot Resident Evil Village
addappid(1196592, 1, "2ae9966da3659f3b3117057e2b7422a710c9538193866decaf4a7e4a6ac51585") --Main Windows Depot Resident Evil Village
addappid(1196593, 1, "95a6023be95ec2186ae5340ee6b7e84f093106e5944e1c8ca09b884622dc41e6") --Main Windows Depot Resident Evil Village
addappid(1196594, 1, "38258feb33272e10fb7214bd6d697ac675b18b968c63a0ee3696a41e2fd50a12") --Main Windows Depot Resident Evil Village
addappid(1456360, 1, "ba65fa909516f46db9fd95fb6a0e266c4d244b386d260346272290642726b63e") --Dlcname Resident Evil Village - Trauma Pack
addappid(1456361, 1, "c847c83484f69cc3195464a7153560fafdd9ec985afb7bf13e2e48ea552dee6d") --Dlcname Resident Evil Village - Extra Content Shop All Access Voucher
addappid(1456362, 1, "46bff99e18ca51b8748333d1dafa1f759b59ca126d648bba42ec8ad386d83827") --Dlcname Resident Evil Village - Mr. Raccoon Weapon Charm
addappid(1456363, 1, "39be524780f16cc175cb4e9813d4d4bb50152d4f72be6a4ea0cb23cf7f4669d3") --Dlcname Resident Evil Village - Survival Resources Pack
addappid(1608280) --Dlcname Resident Evil Village Original Soundtrack
addappid(1608281, 1, "555674ef85c403570c5d053a3f218bcbcd5a1a76ac0d9474a57c1f2a9ce6d654") --Dlc Windows Depot Resident Evil Village Original Soundtrack
addappid(1608282, 1, "d6f2af14f5f29a0b31bfe21ce318c38f9f3069a293235f80f3245034be5cd8b4") --Dlc Windows Depot Resident Evil Village Original Soundtrack
addappid(1608283, 1, "42602529decdad2e6e1baa4cbc078be8ef604912036487806865cf684288265a") --Dlc Windows Depot Resident Evil Village Original Soundtrack
addappid(1608284, 1, "14ed0210e4902d33dfabd7f7d737c381884fd8d1fe36da29982deb899e66ec88") --Dlc Windows Language Depot Japanese Resident Evil Village Original Soundtrack
addappid(1608285, 1, "6ac20aabcd9751ab909adae3497b075d90a4b95df5b240d5d642268dede5f651") --Dlc Windows Language Depot Japanese Resident Evil Village Original Soundtrack
addappid(1608286, 1, "e1311995c156b8ac8382a47cd0e63ef0cec996cb96a8449b0fe88914a5736d13") --Dlc Windows Language Depot Japanese Resident Evil Village Original Soundtrack
addappid(1731080, 1, "caa8356d4e747e982b77b28cfcb1df9095bea681dfae768c0a727a3cd96a9279") --Dlcname Resident Evil Village - Winters’ Expansion
addappid(1196595, 1, "6a79254c10ba889017e23108389c63d5689eb6b50b7d7d22524e9a4f1de24460") --Dlc Windows Depot Resident Evil Village - Winters’ Expansion
addappid(1731081, 1, "69638321e164cb5fd216b2ab217bffa7073fce678124665c60934e972bcf0c2e") --Dlcname Resident Evil Village - Street Wolf Outfit
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables

-- MANIFESTS / UPDATES
setManifestid(1196591, "3932505801699900266", 30318539312)
setManifestid(1196592, "6661267619031919339", 29854562464)
setManifestid(1196593, "5460835064978089028", 68674864)
setManifestid(1196594, "2034632830930715563", 667361968)
setManifestid(1456360, "3932673717585863523", 96473008)
setManifestid(1456361, "5314093679455010857", 66419792)
setManifestid(1456362, "7205803887098070804", 769552)
setManifestid(1456363, "9200672067094795390", 3760)
setManifestid(1608281, "563483019961960081", 153914160)
setManifestid(1608282, "8846547779534392953", 451543216)
setManifestid(1608283, "3451179779183755707", 201270480)
setManifestid(1608284, "2380801648630572260", 153946992)
setManifestid(1608285, "3142279594533461342", 451576640)
setManifestid(1608286, "2890628913519731810", 201304016)
setManifestid(1196595, "2420639041286416875", 6766711344)
setManifestid(1731080, "767965597380462013", 6773287136)
setManifestid(1731081, "3897428114068735554", 70848848)
setManifestid(228988, "6645201662696499616", 22411856)
setManifestid(228990, "1829726630299308803", 100658080)
