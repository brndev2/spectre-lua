-- Lua provided by RyzenAPI
-- Game: Watch_Dogs® 2

-- MAIN APP DEPOTS / PACKAGES
addappid(447040, 1, "22f527ef6fec3336f6bc0e9b2f9fcf2cdd41248bdae7d6716d3857053ecb73e3") --Mainappid Watch_Dogs® 2
addappid(447041, 1, "fc4010cf09dba8216eb41e3c9cb3c070d9560f152196cb6024e79e3f17f25e30") --Main Windows Depot Watch_Dogs® 2
addappid(447042, 1, "678946fb045b108ba74ad0f53329a0c8159fc926efca91b6718517585ae8d7e2") --Main Windows Depot Watch_Dogs® 2
addappid(447043, 1, "e6b3f3a3dc41dee22b161d129bb9b122e5c6a2f52375e39751414142d872966c") --Main Windows Depot Watch_Dogs® 2
addappid(447044, 1, "9c8d01d2514263ec1d948361eb6024344e70a7eb7c6450a9709d586d50c6dad2") --Main Windows Language Depot English Watch_Dogs® 2
addappid(447045, 1, "e25792b08cc6e3b270d8265c8fabd4eb8a270e3efed468c96d4623d7703fafae") --Main Windows Language Depot French Watch_Dogs® 2
addappid(447046, 1, "32d567f43bc976416c7ddc1d45678bbfb80533fce7b8c70d55f30a0ec63288b8") --Main Windows Language Depot Italian Watch_Dogs® 2
addappid(447047, 1, "7fb570147fa727fd08c9f26d495f329678c878237bbeca9d4b462439c75cd74b") --Main Windows Language Depot German Watch_Dogs® 2
addappid(447048, 1, "b4581df8d2c1e5a0d5fd3e9b7179cc7f8f8b56920c9166a6d606dcf781287c2b") --Main Windows Language Depot Spanish Watch_Dogs® 2
addappid(447049, 1, "fdf6bc76a3e2ddd798d1b620fa7e09f432db69215fbecf09ba388d7369103297") --Main Windows Language Depot Russian Watch_Dogs® 2
addappid(523270, 1, "930558d1da6f0df4e392c1da31a5f5865c52abb94c5bc5125c1fc224bb5d8598") --Main Windows Language Depot Brazilian Watch_Dogs® 2
addappid(523271, 1, "8c60696a063ec9810fdab8013e0429bd516850431309169df9b3208050ea3f67") --Main Windows Language Depot Japanese Watch_Dogs® 2
addappid(523272, 1, "d1d96b641664dbea7556a3cd0107767e114acfdfeaa4b35bec66b7c92e36c27a") --Main Windows Language Depot Dutch Watch_Dogs® 2
addappid(523273, 1, "5216b813ab563b947de7d8d45b8fc49219487ae9f7d04f497483cb64e083a451") --Main Windows Language Depot Polish Watch_Dogs® 2
addappid(523274, 1, "b00012ee0c00ff848850d64b9543c01480cf930fd0e2c77f1e789fb60c05120c") --Main Windows Language Depot Czech Watch_Dogs® 2
addappid(523275, 1, "6e55905d4b3fa00548f4e799a40e4cf2063c9d706953e3dd04aa18029100f35f") --Main Windows Language Depot Hungarian Watch_Dogs® 2
addappid(523276, 1, "21bce069ef2a972824611dd8a68bd9ec6d4b3a61d2e68c0414fda6c5a4e932b1") --Main Windows Language Depot Koreana Watch_Dogs® 2
addappid(523277, 1, "c6c310a416c5191a74339fde859b311c71706805769308e58605d2613afd50d6") --Main Windows Language Depot Tchinese Watch_Dogs® 2
addappid(523278, 1, "29be437ec393f5c15a3468c9c7794759fc2d58b53324219ed0a6d288cea8a899") --Main Windows Language Depot Schinese Watch_Dogs® 2
addappid(523279, 1, "a7931d0e7e65cd2b542a9af6359e1b6cac6dd21212b5e80807d52e11b355abeb") --Main Windows Language Depot Arabic Watch_Dogs® 2
addappid(523280, 1, "1c990f3e4447b150cd8f7cd8d8de63c35098fd2cc2bbff9ca20254ab6a5914de") --Main Windows Depot Watch_Dogs® 2
addappid(525000, 1, "7f7c5389bdb55eb129ad979a9f25bb9119d2213b72c20bf9ded7a089b9b140d3") --Dlcname Watch_Dogs 2 -T-Bone Pack
addtoken(525010, "610222037600130084")
addappid(525010, 1, "cd810c8bc9e08fce6eaa195c9a329fc616d21f4e0bb766dbfedb0c7fde1dc5e2") --Dlcname Watch_Dogs 2 - High Res Texture Pack
addappid(525011, 1, "9dbffd3d9fafdab811d3be8a6208cb6924bf74eead3da1213fc73327d544cd47") --Dlcname Watch_Dogs 2 - Root Access Bundle
addappid(525012, 1, "e3e816ba17301fedc531913fae48eb34a2908a80b1a8b5f61ccf7fa10379cfb8") --Dlcname Watch_Dogs 2 - Punk Rock
addtoken(525013, "5734460591535084221")
addappid(525013, 1, "3cd5645e21198ba6a14eedf9e5bae31957d9d69e58c508932d2c3ce732609834") --Dlcname Watch_Dogs 2 - Psychedelic
addappid(525014, 1, "357c21ff0ced6060a2529bd7c3798090d6eae7651dd4e75d340f6bb2a278e4bd") --Dlcname Watch_Dogs 2 - Black hat
addappid(525015, 1, "82020e3b98669314a4fb9bd307edffc343e699ddfd317eb05eb6f2d7f798d766") --Dlcname Watch_Dogs 2 - Pixel Art
addappid(525016, 1, "ec987ead6cd53607ab10a33a73d8a9a0d1d39207b2e24974e81db0e0c2d56744") --Dlcname Watch_Dogs 2 - Guru
addappid(525017, 1, "c2fa62b43a2276d22c672fe08528f5b044548880a79f9e2ed8b1cd21b7524dcd") --Dlcname Watch_Dogs 2 - EliteSec
addappid(525018, 1, "91ac37996aacef4e8cc6f4913b93d61449bd7835dcf5c02218e63af1add634ce") --Dlcname Watch_Dogs 2 - Glam
addappid(525019, 1, "ed3231482c421a8d72104e4b8c42d6ea6afb50fba10da0b294c97bb631fa6a24") --Dlcname Watch_Dogs 2 - Private Eye
addappid(525030, 1, "110a318600e96e739eca55a825805b4635221f867ee024200f33de45a01a945f") --Dlcname Watch_Dogs 2 - Human Conditions
addappid(525031, 1, "d4c8e985e882c44ffce80096d7c027de5c34a59d87fcd0955ee284d560ac3626") --Dlcname Watch_Dogs 2 - No Compromise
addappid(525032, 1, "837184fe6583a2469935f5dd99aef8dcb9b354c978bdbed1a8d069f6bf02a661") --Dlcname Watch_Dogs 2 - Urban Artist
addappid(525033, 1, "13f213413f1c8a3c19323829d8d220d84db2950c565f2556e6800eead21f2039") --Dlcname Watch_Dogs 2 - Ubisoft
addappid(525034, 1, "85a1a4e9c3551688baa44cb2d7b69c4a85af53234fe8d83c8802960dc5533e73") --Dlcname Watch_Dogs 2 - Dumpster Diver
addappid(525035, 1, "986d23fcc348f57f6e9924b4e6125b01612db8b57ab4b7823621eacc1048ba70") --Dlcname Watch_Dogs 2 - Ded Labs
addappid(525036, 1, "9eb3aed80a4013a78b3840b1236ba2ce13e1eb93fcce973a03b43ff158494fa2") --Dlcname Watch_Dogs 2 - Hometown
addappid(525037, 1, "61697e9cb4ae840cc906f9562dea6ee0a91ef31b4c55970440e9d2c33363906e") --Dlcname Watch_Dogs 2 - Guts, Grit and Liberty
addappid(597070, 1, "c3eaa401606a95b8153af0f2c29757005401025517d5de96a2dfa278b6fc727d") --Dlcname Watch_Dogs 2 - Retro Modernist Pack
addappid(597071, 1, "f9563a74f2e98e964f42074b94cc28e99d37c39f048d9e911e21c06f733f42fd") --Dlcname Watch_Dogs 2 - Glow_Pro Pack
addappid(597072, 1, "63e78917f0a2e5d4525306c7ff7a0cf97c828437cbcce37885425f41e1299e0b") --Dlcname Watch_Dogs 2 - Ride Britannia Pack
addappid(597073, 1, "bd769c9d5ab2142217889e096545aa1328bc5cef720639468dd7ee9580e06b97") --Dlcname Watch_Dogs 2 - Kick It Pack
addappid(597074, 1, "54b69ac8918f1b41a621c69b454f30be6613c3a7c5f74dbf93a106eb985c0d23") --Dlcname Watch_Dogs 2 - Velvet Cowboy
addappid(597075, 1, "461868921ac918577ff1ac0e624d5ef1c58b8e9cde5386d62f1cb25753fb27b3") --Dlcname Watch_Dogs 2 - Bay Area Thrash Pack
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") --Share Windows Depot Steamworks Common Redistributables
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") --Share Windows Depot Steamworks Common Redistributables
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") --Share Windows Depot Ubisoft Connect PC Client
addappid(555240) --Dlcname AppID 555240
addtoken(555240, "6315785612364147503")
addappid(558380) --Dlcname AppID 558380
addtoken(558380, "1289165586751349706")
addappid(558381) --Dlcname AppID 558381
addtoken(558381, "14961142203973563193")
addappid(558382) --Dlcname AppID 558382
addtoken(558382, "15279706420928580383")
addappid(558390) --Dlcname Watch_Dogs 2 - Ultimate pack
addappid(558391) --Dlcname Watch_Dogs 2 - Supreme pack
addappid(558400) --Dlcname AppID 558400
addtoken(558400, "2152629169672979296")
addappid(581400) --Dlcname Watch_Dogs 2 - Fully Decked Out Bundle
addappid(597076) --Dlcname Watch_Dogs 2 - Mega Pack
addappid(597077) --Dlcname AppID 597077
addtoken(597077, "14794096060273064851")
addappid(597078) --Dlcname AppID 597078
addtoken(597078, "9518245709529434477")
addappid(597079) --Dlcname AppID 597079
addtoken(597079, "14251259413944811113")
addappid(597100) --Dlcname AppID 597100
addtoken(597100, "9712896617083462579")
addappid(597101) --Dlcname AppID 597101
addtoken(597101, "1610412740109744986")
addappid(597102) --Dlcname AppID 597102
addtoken(597102, "9628153128314448077")
addappid(597103) --Dlcname AppID 597103
addtoken(597103, "291727739420115782")
addappid(609860) --Dlcname AppID 609860
addtoken(609860, "10089511559827480899")
addappid(638030) --Dlcname AppID 638030
addtoken(638030, "7558579898638661010")

-- MANIFESTS / UPDATES
setManifestid(447041, "3302179946055213415", 95936352)
setManifestid(447042, "997218509313186758", 18204916960)
setManifestid(447043, "1462578941831404281", 86496)
setManifestid(447044, "6218236977191698684", 2056925152)
setManifestid(447045, "4453696128671745411", 1950451328)
setManifestid(447046, "8361138808695365836", 2110660496)
setManifestid(447047, "4212646599686875567", 2067806464)
setManifestid(447048, "4034890384220773207", 4375660912)
setManifestid(447049, "6769050862969085397", 1862792560)
setManifestid(523270, "6318734218003619987", 2111945184)
setManifestid(523271, "3235299862685763202", 2003684576)
setManifestid(523272, "909727842574637004", 2056925152)
setManifestid(523273, "6692884236765333991", 2056925152)
setManifestid(523274, "5108994015488200994", 2056925152)
setManifestid(523275, "5896793830775181708", 2056925152)
setManifestid(523276, "8848020721928518196", 2056925152)
setManifestid(523277, "8887530144915320680", 2056925152)
setManifestid(523278, "6790149592184840366", 2056925152)
setManifestid(523279, "2872166881631289131", 2056925152)
setManifestid(523280, "2019220971208328935", 1716383200)
setManifestid(525000, "3818770049609403556", 2016)
setManifestid(525010, "7483836175353315398", 6004874688)
setManifestid(525011, "1533862689114266704", 5344)
setManifestid(525012, "7038970996526637326", 5344)
setManifestid(525013, "7151604820994488599", 5344)
setManifestid(525014, "596936042021230472", 5344)
setManifestid(525015, "2890509369308159084", 5344)
setManifestid(525016, "1654460707176312840", 5344)
setManifestid(525017, "5960420828558892132", 5344)
setManifestid(525018, "1977170010505170029", 5344)
setManifestid(525019, "799387533860932796", 5344)
setManifestid(525030, "961189566217530477", 707151840)
setManifestid(525031, "4871371175234558281", 232540256)
setManifestid(525032, "2323705252351048819", 5344)
setManifestid(525033, "8966076327864415293", 5344)
setManifestid(525034, "4735303425651977581", 5344)
setManifestid(525035, "4979247215084820783", 5344)
setManifestid(525036, "1082048085711066933", 5344)
setManifestid(525037, "8218952416726370481", 5344)
setManifestid(597070, "3993095586736265619", 5344)
setManifestid(597071, "2783599295679915178", 5344)
setManifestid(597072, "1872353120461941193", 5344)
setManifestid(597073, "2885932048396936671", 5344)
setManifestid(597074, "3618130764127901160", 5344)
setManifestid(597075, "1641108175604409131", 5344)
setManifestid(228983, "8124929965194586177", 19214528)
setManifestid(228984, "2547553897526095397", 13436144)
setManifestid(228989, "5753583882400741046", 25108528)
setManifestid(228990, "1829726630299308803", 100658080)
setManifestid(1716751, "6659642105086821873", 264636800)
