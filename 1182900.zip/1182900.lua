-- Lua provided by RyzenAPI
-- Game: A Plague Tale: Requiem

-- MAIN APPLICATION
addappid(1182900)
addappid(1906530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1182901, 1, "89056a553dcf6ee12c8c1a92b728c89e8457fb95ec117f931d7115aa918cbd18")

-- MANIFESTS / UPDATES
setManifestid(228988, "6645201662696499616")
