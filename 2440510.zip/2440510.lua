addappid(2440510) --Mainappid Forza Motorsport
addtoken(2440510, "3368724160899850203")
addappid(2440511, 1, "c7f1787c2ad76d9b13d4db530c1ee953f08e63cb69b9a59c619dcca4736f10c0") --Main Windows Depot Forza Motorsport
setManifestid(2440511, "1248740277997037180", 141575877920)
--Share Depots
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228989, "5753583882400741046", 25108528)
addappid(2557390) --Dlcname Forza Motorsport Car Pass
addappid(2557400) --Dlcname Forza Motorsport VIP
addappid(2557410) --Dlcname Forza Motorsport Race Day Car Pack
addappid(2557420) --Dlcname Forza Motorsport Welcome Pack
addappid(2573690) --Dlcname Forza Motorsport 2018 Volkswagen #22 Experion Racing Golf GTI
addappid(2573700) --Dlcname Forza Motorsport 2019 Dodge #9 American V8 Road Racing TA Challenger
addappid(2573710) --Dlcname Forza Motorsport 1999 Nissan #23 NISMO Clarion R391
addappid(2573720) --Dlcname Forza Motorsport 2020 BMW M2 Competition Coupe
addappid(2573730) --Dlcname Forza Motorsport 2017 Oreca #38 Jackie Chan DC Racing Oreca 07
addappid(2573740) --Dlcname Forza Motorsport 1991 Ford #15 Roush Racing Whistler Mustang
addappid(2612060) --Dlcname Forza Motorsport 1965 Lotus #1 Team Lotus Type 40
addappid(2612070) --Dlcname Forza Motorsport 2019 McLaren #03 720S GT3
addappid(2612080) --Dlcname Forza Motorsport 2018 Mercedes-AMG GT3
addappid(2612090) --Dlcname Forza Motorsport 2018 Peugeot #7 DG Sport Compétition 308
addappid(2612100) --Dlcname Forza Motorsport 2018 Chevrolet #23 Ruman Racing TA Corvette
addappid(2612110) --Dlcname Forza Motorsport 1985 Buick #6 Performance Motorsports Somerset Regal Trans-Am
addappid(2612120) --Dlcname Forza Motorsport 2021 Cadillac #31 Whelen Racing DPi-V.R
addappid(2612130) --Dlcname Forza Motorsport 2018 Lamborghini #63 Squadra Corse Huracán Super Trofeo Evo
addappid(2612140) --Dlcname Forza Motorsport 1983 Porsche #11 John Fitzpatrick Racing 956
addappid(2612150) --Dlcname Forza Motorsport 2019 McLaren Senna GTR
addappid(2613770) --Dlcname Forza Motorsport Premium VIP
addappid(2662850) --Dlcname Forza Motorsport 2019 Ferrari #62 Risi Competizione 488 GTE
addappid(2662860) --Dlcname Forza Motorsport 2022 Aston Martin Valkyrie AMR Pro
addappid(2662880) --Dlcname Forza Motorsport 1966 Lotus type 35
addappid(2662890) --Dlcname Forza Motorsport 2015 Cadillac #3 Cadillac Racing ATS-V.R
addappid(2662900) --Dlcname Forza Motorsport 2018 Ford #98 Breathless Pro Racing TA Mustang
addappid(2662910) --Dlcname Forza Motorsport 2020 Audi TT RS Coupe
addappid(2662930) --Dlcname Forza Motorsport 2019 Toyota 86 TRD SE
addappid(2662940) --Dlcname Forza Motorsport 2020 Lexus #14 VASSER SULLIVAN RC F GT3
addappid(2662950) --Dlcname Forza Motorsport 1986 Lotus #12 Team Lotus 98T
addappid(2673230) --Dlcname Forza Motorsport 2018 Cadillac #57 TA CTS-V
addappid(2728110) --Dlcname Forza Motorsport Promo Item 2
addappid(2731660) --Dlcname Forza Motorsport Promo Item
addappid(2833110) --Dlcname Forza Motorsport 1983 Nissan #23 Nissan Motorsports Silvia Super Silhouette
addappid(2833220) --Dlcname Forza Motorsport 1970 Matra-Simca #146 Equipe Matra-Simca MS650 Tour de France
addappid(2833230) --Dlcname Forza Motorsport 2016 Ligier #11 Eurointernational JS P3
addappid(2862340) --Dlcname Forza Motorsport 2019 Ginetta G55 GT4
addappid(2921330) --Dlcname Forza Motorsport Porsche 963 Combo
addappid(3026540) --Dlcname Forza Motorsport Duracell Suit
addappid(3118460) --Dlcname Forza Motorsport 2024 Ford Mustang Dark Horse
addappid(3472460) --Dlcname Forza Motorsport: Racing Heroes Car Pack