-- Lua provided by RyzenAPI
-- Game: Star Wars Outlaws

-- MAIN APP DEPOTS / PACKAGES
addappid(2842040, 1, "3682fe856a5ecf5300cc85aa1b928b94995428d60a24ad1b9be2237e70ef1896") --Mainappid Star Wars Outlaws
addappid(2842041, 1, "bed1b2aedb9b823e084bde3a15663caf8f50feaadd104bba0c7e474540a11f43") --Main Windows Depot Star Wars Outlaws
addappid(2842042, 1, "110e9180cab6db688b21cc6f16820d8197b333d0c1d88b66da81d43753a9c786") --Main Windows Language Depot French Star Wars Outlaws
addappid(2842043, 1, "2d98d4345bb461b3ee9574d5e4f00cf62e968042031e7d7361b3d15d09282788") --Main Windows Language Depot German Star Wars Outlaws
addappid(2842044, 1, "dbaf8d54cceac51941390dffb5257608db23f202ec6d06d61fae96fed743e9d9") --Main Windows Language Depot Spanish Star Wars Outlaws
addappid(2842045, 1, "845fbe248a74375c3dda44984552af44018332d3b7f355dce4d1c833727e0a42") --Main Windows Language Depot Brazilian Star Wars Outlaws
addappid(2842046, 1, "58faa2a3ab11d95ab7d448ae380c4211c92726b9fcf619835d2b3900356506ac") --Main Windows Language Depot Japanese Star Wars Outlaws
addappid(3271130, 1, "cd4259d93979d9d480227cf581dbb3855b238747fa76988d8c94da591300669e") --Dlcname Star Wars Outlaws - DLC1
addappid(3541390, 1, "a2c323e9b71ce1d184500fedc2ddaf67f9f96af0f57324757cb7f9949f71944a") --Dlcname Star Wars Outlaws - A Pirate's Fortune DLC
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") --Share Windows Depot Ubisoft Connect PC Client
addappid(3112310) --Dlcname Star Wars Outlaws - DLC1 - Ubisoft Activation
addappid(3261290) --Dlcname Star Wars Outlaws - Gold Edition - Ubisoft Activation
addappid(3261340) --Dlcname Star Wars Outlaws - Ultimate Edition - Ubisoft Activation
addappid(3271140) --Dlcname Star Wars Outlaws - Season Pass
addappid(3271150) --Dlcname Star Wars Outlaws - Season Pass - Ubisoft Activation
addappid(3271160) --Dlcname Star Wars Outlaws - Ultimate Pack
addappid(3271170) --Dlcname Star Wars Outlaws - Ultimate Pack - Ubisoft Activation
addappid(3271180) --Dlcname Star Wars Outlaws - Forrest Commando
addappid(3271190) --Dlcname Star Wars Outlaws - Forrest Commando - Ubisoft Activation
addappid(3271200) --Dlcname Star Wars Outlaws - Hunter's Legacy
addappid(3271210) --Dlcname Star Wars Outlaws - Hunter's Legacy - Ubisoft Activation
addappid(3271230) --Dlcname Star Wars Outlaws - Cartel Ronin
addappid(3271240) --Dlcname Star Wars Outlaws - Cartel Ronin - Ubisoft Activation
addappid(3271460) --Dlcname Star Wars Outlaws - Standard Edition - Ubisoft Activation
addappid(3394020) --Dlcname Star Wars Outlaws - Deluxe Edition - Ubisoft Activation
addappid(3515960) --Dlcname Star Wars Outlaws Demo - Ubisoft Activation
addappid(3541410) --Dlcname Star Wars Outlaws - A Pirate's Fortune DLC - Ubisoft Activation
addappid(3702240) --Dlcname Star Wars Outlaws - Naboo Nobility Bundle
addappid(3702250) --Dlcname Star Wars Outlaws - Naboo Nobility Bundle Ubisoft Activation
addappid(3702260) --Dlcname Star Wars Outlaws - Desert Nomad Bundle
addappid(3702270) --Dlcname Star Wars Outlaws - Desert Nomad Bundle Ubisoft Activation

-- MANIFESTS / UPDATES
setManifestid(2842041, "5039899775321241999", 63846188256)
setManifestid(2842042, "8023630815732376815", 2499220176)
setManifestid(2842043, "4839953097128885780", 2654756336)
setManifestid(2842044, "7424665147348076845", 2851600976)
setManifestid(2842045, "6353372299728446551", 2770636128)
setManifestid(2842046, "7478173584789464744", 2725714208)
setManifestid(3271130, "3969923851033101926", 1100818160)
setManifestid(3541390, "6063451016620732592", 2059912608)
setManifestid(228989, "5753583882400741046", 25108528)
setManifestid(228990, "1829726630299308803", 100658080)
setManifestid(1716751, "6659642105086821873", 264636800)
