-- Lua provided by RyzenAPI
-- Game: ELDEN RING

-- MAIN APP DEPOTS / PACKAGES
addappid(1245620, 1, "10f99dee41d0f96e312cf8c574420de0a018b6a26caf4c3e3aefa13cf90c1246") --Mainappid ELDEN RING
addappid(1245621, 1, "5f560fca048a138487e1e634a1e60693a7ad3ae7318c31731d147f16e093f10b") --Main Windows Depot ELDEN RING
addappid(1245623, 1, "b27090a72caa5f3cf2e1f41a81c4bc1c422a6ac277e1cd3a6f1ea68200288d4b") --Main Windows Depot ELDEN RING
addappid(1245624, 1, "e194ce5e5f83c427743781c1708c4bce6683d5d65521059f6e4ca64a8f36f3cd") --Main Windows Depot ELDEN RING
addappid(1896300, 1, "946e5c4e2c91a3ed363efc688218994f7fa6e8fdd56aa8b5752456d3b28e0543") --Dlcname ELDEN RING Digital Artbook & Original Soundtrack
addappid(1896320, 1, "de7086b709fdfc7d151bfce5d07509fd80a6c318a21e8fb1e820db5b1cda5860") --Dlcname ELDEN RING Adventure Guide
addappid(2778580, 1, "9f1556645ea8ef43529f920cf02a2682a6da5756b29e630ba376a0cde24e3908") --Dlcname ELDEN RING Shadow of the Erdtree
addappid(2855520, 1, "476eca9191866d6743aa7ad82d4d7ce1fcd5e0f0613f2f4b6559635d68f8c0e3") --Dlcname ELDEN RING Shadow of the Erdtree - Artbook & Soundtrack
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") --Share Windows Depot Steamworks Common Redistributables
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
addappid(1922350) --Dlcname ELDEN RING - EU Pre-Purchase DLC Bundle
addappid(2778590) --Dlcname ELDEN RING Shadow of the Erdtree Premium Bundle
addappid(2855530) --Dlcname ELDEN RING Shadow of the Erdtree Bonus Gesture

-- MANIFESTS / UPDATES
setManifestid(1245621, "3886039026718227526", 53397798832)
setManifestid(1245623, "3635787787034027333", 36920496)
setManifestid(1245624, "3497793843869306771", 36920112)
setManifestid(1896300, "7130086783926325209", 936446208)
setManifestid(1896320, "5664821938092422533", 673563792)
setManifestid(2778580, "1674424364022381183", 16035698400)
setManifestid(2855520, "2785904640065824767", 830901184)
setManifestid(228988, "6645201662696499616", 22411856)
setManifestid(228990, "1829726630299308803", 100658080)
