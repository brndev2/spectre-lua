-- ============================================================
-- Descargado desde Walftech  ->  https://walftech.com
-- Generador de Manifest y Lua
-- AppID: 824270
-- Fecha: 2026-11-03 19:33 UTC
-- ============================================================

addappid(824270)
addappid(228989)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(824271,0,"eb3bfa996ec2fa95ac46deb12cac451a680c017946edfb52209740273157dd1c")
setManifestid(824271,"6505541369217727758")
addappid(1438210)
addappid(2633870)

--[[
Descargado desde Walftech: https://walftech.com/
Discord: https://discord.com/invite/5m6vtWSpVD
]]
